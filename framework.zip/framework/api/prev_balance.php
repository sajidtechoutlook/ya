<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

echo getCustomerPreviousBalance(createNewCustomer($_REQUEST['customer']), _getDBDateTime($_REQUEST['t']));