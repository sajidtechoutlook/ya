var app = angular.module('mod', []);

app.controller('sale_form_ctr', ['$scope', '$rootScope', function($scope, $rootScope){
    $scope.bills_array = new Array();
    $scope.arr_tmp = new Array();
    $scope.arr_form = new Array();
    $scope.arr_form.gross_total = 0;
    $scope.arr_form.qty_total = 0;
    $scope.arr_form.total = 0;
    $scope.arr_form.gst_total = 0;
    $scope.arr_form.balance = 0;
    $scope.arr_form.bill_total = 0;
    $scope.arr_form.amount_paid = 0;
    $scope.arr_form.discount_desc = 0;
    $scope.arr_form.discount = 0;
    $scope.arr_form.discountinpercent = 0;
    $scope.arr_form.extrachargesdesc = "";
    $scope.arr_form.exchrgs = 0;
    $scope.arr_form.saletax = 0;
    $scope.arr_form.fileno = '';
    $scope.arr_form.customer = '';
    $scope.arr_form.phoneno = '';
    $scope.arr_form.saleman_id = 0;
    $scope.arr_form.payment_type = 0;
    $scope.arr_form.prev_balance = 1200;
    $scope.arr_form.dt = getCurrentDateTime();
    
    $scope.sr = 1;
    $scope.id = 0;
    $scope.arr_form.billarray = new Array();

    $scope.setPrevBalance = function (){
        $scope.arr_form.prev_balance = 12;
    }
    $scope.addRow = function (){
        $scope.arr_tmp = new Array();
        if($('#product_search').val() == '') return false;
        $scope.$arr = {
            sr: $scope.sr++, 
            item: $('#product_search').val(), 
            quantity: $('#qty').val(),
            qty_packs: $('#qty_packs').val(),
            price: $('#price').val(),
            discount: $('#discount').val(),
            quantity_packs: $('#quantity_packs').val(),
            
            subtotal: $('#price').val() * $('#qty').val()
        };
        angular.forEach($scope.arr_form.billarray, function(value, key) {
            if(value.item == $('#product_search').val()){
                value.quantity = parseFloat(value.quantity) + parseFloat($('#qty').val());
                $scope.arr_tmp.push(value);
                $scope.already_exists = true;
            }else{
                $scope.arr_tmp.push(value);
            }
            $scope.$arr.sr = $scope.$arr.sr+1;
        });
        if($scope.already_exists == true){
            $scope.arr_form.billarray = $scope.arr_tmp;
        }else{
            $scope.arr_form.billarray.push($scope.$arr);
        }
        // $scope.arr_form.billarray.push($scope.$arr);
        // if ($scope.arr_form.billarray.length == 0){
        //     $scope.arr_form.billarray.push($scope.$arr);
        // }
        // alert($scope.arr_form.billarray.length);
        
        $scope.updateForm();
        $scope.already_exists = false;
        $('#product_search').focus();
        $('#product_barcode_search').focus();
    }
    $scope.deleteRow = function (index){
        $scope.sr = 1;
        $scope.arr_tmp = new Array();
        angular.forEach($scope.arr_form.billarray, function(value, key) {
            value.sr = $scope.sr;
            if(value.item != index){
                $scope.arr_tmp.push(value);
                $scope.sr++;
            }
        });
        $scope.arr_form.billarray = $scope.arr_tmp;
        $scope.updateForm();
        $('#product_search').focus();
        $('#product_barcode_search').focus();
    }
    $scope.updateForm = function(){
        $('#product_barcode_search').val(""),
        $('#product_search').val(""),
        $('#qty').val(1),
        $('#qty_packs').val(""),
        $('#price').val(""),
        $('#discounts').val(""),
        $('#sale_discount').val("");
        $scope.arr_form.gross_total = 0;
        if(!$scope.arr_form.gst_total > 0) $scope.arr_form.gst_total = 0; else parseFloat($scope.arr_form.gst_total);
        if(!$scope.arr_form.balance > 0) $scope.arr_form.balance = 0; else parseFloat($scope.arr_form.balance);
        if(!$scope.arr_form.saletax > 0) $scope.arr_form.saletax = 0; else parseFloat($scope.arr_form.saletax);
        if(!$scope.arr_form.bill_total > 0) $scope.arr_form.bill_total = 0; else parseFloat($scope.arr_form.bill_total);
        if(!$scope.arr_form.amount_paid > 0) $scope.arr_form.amount_paid = 0; else parseFloat($scope.arr_form.amount_paid);
        if(!$scope.arr_form.discount > 0) $scope.arr_form.discount = 0; else parseFloat($scope.arr_form.discount);
        if(!$scope.arr_form.discountinpercent > 0) $scope.arr_form.discountinpercent = 0; else parseFloat($scope.arr_form.discountinpercent);
        if(!$scope.arr_form.exchrgs > 0) $scope.arr_form.exchrgs = 0; else parseFloat($scope.arr_form.exchrgs);

        $scope.arr_tmp = new Array();
        $scope.$count = 1;
        $scope.arr_form.qty_total = 0;
        angular.forEach($scope.arr_form.billarray, function(value, key) {
            value.sr = $scope.$count++;
            if(!value.discount > 0) value.discount = 0;
            value.subtotal = parseFloat(value.quantity * (value.price - value.discount));
            $scope.arr_tmp.push(value);
            $scope.arr_form.gross_total += parseFloat(value.subtotal);
            $scope.arr_form.qty_total += parseFloat(value.quantity);
        });
        // $scope.arr_form.gross_total = 1000;
        $scope.arr_form.billarray = $scope.arr_tmp;
        $scope.arr_form.gst_total = parseFloat(parseFloat($scope.arr_form.gross_total) / 100 * parseFloat($scope.arr_form.saletax));
        $scope.arr_form.bill_total = parseFloat($scope.arr_form.gross_total) + parseFloat($scope.arr_form.gst_total) + parseFloat($scope.arr_form.exchrgs) - parseFloat($scope.arr_form.discount);
        $scope.arr_form.balance = parseFloat($scope.arr_form.bill_total) - parseFloat($scope.arr_form.amount_paid) + parseFloat($('#prev_balance').html());
    }

    
    $scope.completeTheSale = function(){
        $scope.updateForm();
        window.print();
        //reloadProducts();
        $scope.arr_form_tmp = new Array();

        $bill_data = {
            'gross_total': $scope.arr_form.gross_total,
            'total': $scope.arr_form.total,
            'gst_total': $scope.arr_form.gst_total,
            'balance': $scope.arr_form.balance,
            'bill_total': $scope.arr_form.bill_total,
            'amount_paid': $scope.arr_form.amount_paid,
            'discount_desc': $scope.arr_form.discount_desc,
            'discount': $scope.arr_form.discount,
            'discountinpercent': $scope.arr_form.discountinpercent,
            'extrachargesdesc': $scope.arr_form.extrachargesdesc,
            'exchrgs': $scope.arr_form.exchrgs,
            'saletax': $scope.arr_form.saletax,
            'fileno': $scope.arr_form.fileno,
            'customer': $('#customer').val(),
            'phoneno': $('#phoneno').val(),
            'saleman_id': $scope.arr_form.saleman_id,
            'payment_type': $scope.arr_form.payment_type,
            
            'dt': $scope.arr_form.dt
        };
        $scope.arr_form_tmp = {'bill_data': $bill_data, 'bill_items': $scope.arr_form.billarray};
        $scope.bills_array = getCookie('ya_bills');
        if($scope.bills_array.length < 1){
            $scope.bills_array = new Array();
        }else{
            //alert($scope.bills_array);
            console.log($scope.bills_array);
        }
        $scope.bills_array.push($scope.arr_form_tmp);
        setCookie('ya_bills', $scope.bills_array, 360);
        //$response = saveBillToServer($scope.arr_form_tmp);
        $scope.startNewSale();
        $('#bills_to_sync').html('Synching <sup>('+$scope.bills_array.length+')</sup>');
        //alert($scope.bills_array.length);
    }
    
    $scope.startNewSale = function(){
        //$scope.bills_array = new Array();
        $scope.arr_tmp = new Array();
        $scope.arr_form = new Array();
        $scope.arr_form.gross_total = 0;
        $scope.arr_form.total = 0;
        $scope.arr_form.gst_total = 0;
        $scope.arr_form.balance = 0;
        $scope.arr_form.bill_total = 0;
        $scope.arr_form.amount_paid = 0;
        $scope.arr_form.discount_desc = 0;
        $scope.arr_form.discount = 0;
        $scope.arr_form.discountinpercent = 0;
        $scope.arr_form.extrachargesdesc = "";
        $scope.arr_form.exchrgs = 0;
        $scope.arr_form.saletax = 0;
        $scope.arr_form.fileno = '';
        $scope.arr_form.customer = '';
        $scope.arr_form.phoneno = '';
        $scope.arr_form.saleman_id = 0;
        $scope.arr_form.payment_type = 0;
        $scope.arr_form.dt = getCurrentDateTime();
        
        $scope.sr = 1;
        $scope.id = 0;
        $scope.arr_form.billarray = new Array();
    }
    $scope.roGetNextInvoiceID = function(){
        $.ajax({
            type: 'POST',
            data: {},
            url: '<?php echo getApiUrl('get_next_invoice_id').'&t='.time();?>',                      
            complete: function(res) {
                $scope.arr_form.invoice_id = res.responseJSON;
            }
        });
    }
    $scope.sendDataToServer = function(){
        //console.log($scope.bills_array);
        //return;
        $.ajax({
            type: 'POST',
            data: {postdata: JSON.stringify(getCookie('ya_bills'))},
            // contentType: "application/json",
            url: '<?php echo getApiUrl('save_the_sales').'&t='.time();?>',                      
            complete: function(res) {
                if(res.readyState == 4){
                    $scope.bills_array = new Array();
                    deleteCookie('ya_bills');
                    console.log(res.readyState);
                    $('#bills_to_sync').html('');
                    //alert(2);
                }
            }
        });
        //alert(1);
    }
    $scope.syncServer = function(){
        setTimeout(function() { 
            if(delayCompleted()){
                $scope.sendDataToServer();
                $scope.syncServer();
            }
        }, delay);
    }
    $scope.roGetNextInvoiceID();
    $scope.syncServer();
}]);
var delay = 30000;
var prev_run = Date.now();
function delayCompleted(){
    if(Date.now() > prev_run+delay){
        prev_run+=delay;
        return true;
    }
    return false;
}
function saveBillToServer($billarray) {
    $.ajax({
        type: 'POST',
        data: {postdata: JSON.stringify($billarray)},
        // contentType: "application/json",
        url: '<?php echo getApiUrl('save_this_sale').'&t='.time();?>',                      
        complete: function(res) {
          //console.log(res.responseText);
        }
    });
}

function getCurrentDateTime(){
    var d = new Date();
    var curr_secs	= d.getSeconds();
    var curr_min 	= d.getMinutes();
    var curr_hour 	= d.getHours();
    var curr_date 	= d.getDate();
    var curr_month	= d.getMonth()+1;
    var curr_year	= d.getFullYear();
    if(curr_month < 10) curr_month = '0'+curr_month;
    if(curr_date < 10) curr_date = '0'+curr_date;
    var dtm = curr_date+'-'+curr_month+'-'+curr_year+' '+curr_hour+':'+curr_min;
    return dtm;
}

//reloadProducts();
function setCookie(cname, cvalue, exdays) {
    localStorage.setItem(cname, JSON.stringify(cvalue) );
    return;

    jQuery.cookie(cname, JSON.stringify(cvalue));
    return;
  const d = new Date();
  d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
  let expires = "expires="+d.toUTCString();
  document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function getCookie(cname) {
    val = localStorage.getItem(cname);
    if(val == null || val==''){
        return new Array();
    }else{
        return jQuery.parseJSON(val);
    }
    return jQuery.parseJSON(jQuery.cookie(cname));
    let name = cname + "=";
    let ca = document.cookie.split(';');
    for(let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) == ' ') {
        c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
        }
  }
  return "";
}

function checkCookie(cname) {
  let user = getCookie(cname);
  if (user != "") {
    alert("Welcome again " + user);
  } else {
    user = prompt("Please enter your name:", "");
    if (user != "" && user != null) {
      setCookie(cname, user, 365);
    }
  }
}

function deleteCookie(cname){
    localStorage.setItem(cname, JSON.stringify('') );
    //document.cookie = cname+"=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
}