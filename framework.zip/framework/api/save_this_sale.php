<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$postdata = (json_decode(stripslashes($_REQUEST['postdata'])));
// print_r($postdata->bill_data);
// print_r($postdata->bill_items);
// die;

$customer_id = createNewCustomer($postdata->bill_data->customer, $postdata->bill_data->phoneno);
$Total = 0;
$postdata->bill_data->exchrgs = (isset($postdata->bill_data->exchrgs))?$postdata->bill_data->exchrgs:0;
foreach($postdata->bill_data as $elementname=>$value){
    if(!is_array($value))
        $postdata->bill_data->$elementname = stripslashes($value);
}
$maxrtno = getNextSaleRTNO();
$sale_q = "(	
        userid,
        worker_id,
        customerid,
        dt,
        rtno,
        fileno,
        total,
        gst,
        extrachargesdesc,
        extracharges,
        discount_desc,
        discountinpercent,
        discount,
        status
        ) values (
        '".getBusinessId()."',
        '".$postdata->bill_data->saleman_id."',
        '".$customer_id."',
        '"._getDBDateTime($postdata->bill_data->dt)."',
        '".$maxrtno."',
        '".$postdata->bill_data->fileno."',
        '".$postdata->bill_data->total."',
        '".$postdata->bill_data->gst_total."',
        '".$postdata->bill_data->extrachargesdesc."',
        '".$postdata->bill_data->exchrgs."',
        '".$postdata->bill_data->discount_desc."',
        '".$postdata->bill_data->discountinpercent."',
        '".$postdata->bill_data->discount."',
        1)";
$sale_id = $dblink->writeToDB($sale_q, $rodb->prefix."sale");
$sale_id = $sale_id[1];
// print_r($postdata->bill_items);
foreach($postdata->bill_items as $bill_item)
{
        $product_id = createNewProduct($bill_item->item, $bill_item->price, 0);
        $err = $dblink->updateInDB(" stock=stock-".$bill_item->quantity, "productid='".$product_id."'", $rodb->prefix ."product");
        $prd = $dblink->getTableFromDB("select * from ".$rodb->prefix ."product where productid='".$product_id."'");

        $dblink->writeToDB("(ps_productid,ps_productname,ps_userid,ps_stock,ps_date) values (
        '".$product_id."',
        '".$bill_item->item."',
        '".getBusinessId()."',
        '".$prd[0]['stock']."',
        '"._getDBDateTime($postdata->bill_data->dt)."'
        )",$rodb->prefix ."product_stock");

        $dblink->writeToDB("(	
                productid,
                productname,
                sale_price,
                sale_discount,
                qty,
                qty_packs,
                sale_id,
                userid) values (
                '".$product_id."',
                '".$bill_item->item."',
                '".$bill_item->price."',
                '0',
                '".$bill_item->quantity."',
                '0',
                '".$sale_id."',
                '".getBusinessId()."'
                )", $rodb->prefix ."sale_products");
                // echo $bill_item->quantity.' * '.$bill_item->price;
        $Total += ($bill_item->quantity*$bill_item->price)-((isset($bill_item->discount))?$bill_item->discount:0);
}
$gstTotal = $Total + ($Total*$postdata->bill_data->saletax/100);

if(isset($postdata->bill_data->discountinpercentcheck)){
        $discount = $Total * $postdata->bill_data->discountinpercent/100;
}else{
        $discount = (isset($postdata->bill_data->discount))?$postdata->bill_data->discount:0;
}
$gTotal = $gstTotal - $discount + $postdata->bill_data->exchrgs;

// $err = updateSale($sale_id, _getDBDateTime($postdata->bill_data->dt), $maxrtno, $Total, $gTotal);
updateSaleVariables($sale_id, array('total' => $Total, 'gTotal' => $gTotal, 'worker_id' => $postdata->bill_data->saleman_id, 'status' => 1));
// if(isset($postdata->bill_data->saleman_id))
// 	updateSaleVariables($sale_id, array());
// if(isset($postdata->bill_data->fileno))
// 	updateSaleVariables($sale_id, array('fileno' => $postdata->bill_data->fileno));
// if(isset($postdata->bill_data->saletax))
// 	updateSaleVariables($sale_id, array('gst' => $postdata->bill_data->saletax));
updateCustomerBalance(getBusinessId(), $customer_id, 0, $gTotal, $postdata->bill_data->payment_type, _getDBDateTime($postdata->bill_data->dt));
// completeSale($sale_id);
if($postdata->bill_data->amount_paid > 0){
	make_transaction(getBusinessId(), $customer_id, $postdata->bill_data->amount_paid, $postdata->bill_data->payment_type, date('Y-m-d H:i:s', strtotime(_getDBDateTime($postdata->bill_data->dt))+60));
}

// $phoneno = $rodb->getCellFromDB("select customer_phone from ". $rodb->prefix ."customers where customer_id = '".$rodb->mysql_real_escape_string($customer_id)."'");

// $msg = "Thanks for your purchase.
// Your Receipt# is $maxrtno". 
// ", Total: ".$gTotal;
// send_sms($phoneno, $msg);

$ledger = (isset($customer_id))?makeCustomerLedger($customer_id):'';
?>