<script type="text/javascript">
    var products_label = [
        <?php $products = $rodb->getProducts(getBusinessId());
        if(isset($products) && is_array($products) && count($products) > 0)
        foreach($products as $product){
            echo '{
            value: "'.str_replace("'", '', str_replace('"', '', $product['productname'])).'",
            label: "'.str_replace("'", '', str_replace('"', '', $product['productname'])).'",
            desc: "'.str_replace("'", '', str_replace('"', '', $product['productname'])).'",
            stock: "'.str_replace("'", '', str_replace('"', '', $product['stock'])).'",
            price: "'.getSalePrice($product['productid'], $_REQUEST['customer']).'",
            id: '.$product['productid'].'},';
        }
        ?>
    ];

    $( "#product_search" ).autocomplete({
minLength: 0,
source: products_label,
focus: function( event, ui ) {
//$( "#product_barcode_search" ).val( ui.item.value );
$( "#product_search" ).val( ui.item.desc );
$( "#product" ).val( ui.item.id );
$( "#price" ).val( ui.item.price );
$( "#available_stock" ).html( '('+ ui.item.stock +')' );
return false;
},
select: function( event, ui ) {
//$( "#product_barcode_search" ).val( ui.item.value );
$( "#product_search" ).val( ui.item.desc );
$( "#product" ).val( ui.item.id );
// document.addtobill_form.submit();
// addToBill();
return false;
}
})
.data( "ui-autocomplete" )._renderItem = function( ul, item ) {
return $( "<li>" )
.append( "<a>" + item.desc + "</a>" )
.appendTo( ul );
};
/////////////////////////////////////////
var products = [
<?php $products = $rodb->getProducts(getBusinessId());
if(isset($products) && is_array($products) && count($products) > 0)
foreach($products as $product){
    echo '{
value: "'.$product['productid'].'",
productcode: "'.$product['productcode'].'",
label: "'.$product['productid'].'",
desc: "'.str_replace("'", '', str_replace('"', '', $product['productname'])).'",
price: "'.$product['sale_price'].'",
stock: "'.$product['stock'].'",
id: '.$product['productid'].'},';
}
?>
];
$( "#product_barcode_search" ).autocomplete({
minLength: 0,
source: products,
focus: function( event, ui ) {
$( "#product_barcode_search" ).val( ui.item.productcode );
$( "#product_search" ).val( ui.item.desc );
$( "#product" ).val( ui.item.id );
$( "#price" ).val( ui.item.price );
return false;
},
select: function( event, ui ) {
$( "#product_barcode_search" ).val( ui.item.productcode );
$( "#product_search" ).val( ui.item.desc );
$( "#product" ).val( ui.item.id );
// document.addtobill_form.submit();
// addToBill();
return false;
}
})
.data( "ui-autocomplete" )._renderItem = function( ul, item ) {
return $( "<li>" )
.append( "<a>" + item.productcode + "</a>" )
.appendTo( ul );
};
</script>