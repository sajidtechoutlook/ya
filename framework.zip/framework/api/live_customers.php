<script type="text/javascript">
    var customers = [
    <?php $customers = $rodb->getCustomers(getBusinessId());
if(isset($customers) && is_array($customers) && count($customers) > 0)
foreach($customers as $customer){
    echo '{
value: "'.str_replace("'", '', str_replace('"', '', $customer['customer_name'])).'",
label: "'.str_replace("'", '', str_replace('"', '', $customer['customer_name'])).'",
desc: "'.str_replace("'", '', str_replace('"', '', $customer['customer_name'])).'",
phone: "'.str_replace("'", '', str_replace('"', '', $customer['customer_phone'])).'",
address: "'.str_replace("'", '', str_replace('"', '', $customer['customer_address'])).'",
id: '.$customer['customer_id'].'},';
}
?>
];
$( "#customer" ).autocomplete({
minLength: 0,
source: customers,
focus: function( event, ui ) {
$( "#customer" ).val( ui.item.label );
$( "#customer_id" ).val( ui.item.id );
$( "#phoneno" ).val( ui.item.phone );
$( "#address" ).val( ui.item.address );
return false;
},
select: function( event, ui ) {
$( "#customer" ).val( ui.item.label );
$( "#phoneno" ).val( ui.item.phone );
$( "#customer_id" ).val( ui.item.id );
$( "#address" ).html( ui.item.address );
loadLiveProducts(ui.item.id);
getPrevBalance(ui.item.id);
return false;
}
})
.data( "ui-autocomplete" )._renderItem = function( ul, item ) {
return $( "<li>" )
.append( "<a>" + item.label + "</a>" )
.appendTo( ul );
};
</script>