<?php 
// $start_date = (isset($_REQUEST['fromyear']) && isset($_REQUEST['frommonth']) && isset($_REQUEST['fromday']))?$_REQUEST['fromyear']."-".$_REQUEST['frommonth']."-".$_REQUEST['fromday']:'';
// $end_date = (isset($_REQUEST['toyear']) && isset($_REQUEST['tomonth']) && isset($_REQUEST['today']))?$_REQUEST['toyear']."-".$_REQUEST['tomonth']."-".$_REQUEST['today'].' 23:59:59':'';
$start_date = '1979-1-1';
$end_date = @date('Y-m-d 23-59-59');
$total_debit = (isset($total_debit))?$total_debit:0;
$total_credit = (isset($total_credit))?$total_credit:0;

if(!isset($_REQUEST['customerid']) || $_REQUEST['customerid'] == ''){
	$_REQUEST['customerid'] = 1;
}
$custinfo = $rodb->getTableFromDB(" select * from ".$rodb->prefix."customers where customer_id='".$_REQUEST['customerid']."' and user_id = '".getBusinessId()."'");
if(isset($custinfo) && is_array($custinfo))
$current_balance = $dblink->getCellFromDB(" select cb_balance from ".$rodb->prefix."customer_balance where cb_userid='".getBusinessId()."' and cb_date = (select max(cb_date) from ".$rodb->prefix."customer_balance where cb_date < '".$start_date."' and cb_userid='".getBusinessId()."' and cb_customerid = '".$custinfo[0]['customer_id']."') ");

if(isset($current_balance) && !$current_balance>0){
    if($custinfo[0]['dt'] > $start_date){
        $current_balance=$custinfo[0]['opening_balance'];
    }else{
        $current_balance=0;
    }
}
$delete_customer_balance_q = "delete from ".$rodb->prefix."customer_balance where cb_userid = '".getBusinessId()."' and cb_customerid = '".$_REQUEST['customerid']."'";
$rodb->execute($delete_customer_balance_q);

?>
<table border="1" bordercolor="#CCCCCC" cellpadding="0" cellspacing="0" width="100%" align="center" style="border-collapse:collapse">
	<tr>
		<td>
			<table border="1" width="100%" align="center" border="0" cellpadding="1" cellspacing="1">
			<tr bgcolor="#EDE7EB">
			  <td colspan="6" align="center"> <h1 style="color:#003366">"<?php echo isset($custinfo[0]['customer_name'])?$custinfo[0]['customer_name']:'Cash';?>" Ledger</h1> </td>
			</tr>
			<tr bgcolor="#F7F7F7" style="display: none">
				<td colspan="3">&nbsp;<strong style="color:#006600">Opening Balance: <?php echo $current_balance;?></strong></td>
			</tr>
			<tr bgcolor="#999999">
			  <td width="186" align="left">&nbsp;<strong style="color:#993300">Date</strong></td>
			  <td width="204" align="left">&nbsp;<strong style="color:#993300">Description </strong></td>
			  <td width="207" align="left">&nbsp;<strong style="color:#993300">File# </strong></td>
			  <td width="175" align="left">&nbsp;<strong style="color:#993300">Sent</strong></td>
			  <td width="183" align="left">&nbsp;<strong style="color:#993300">Received </strong></td>
			  <td width="207" align="left">&nbsp;<strong style="color:#993300">Balance </strong></td>
			</tr>
			<?php
			$invoicesq = " select * from ".$rodb->prefix."sale where customerid='".$_REQUEST['customerid']."' and userid='".getBusinessId()."' order by dt asc, rtno asc, id asc ";
			$invoices = $dblink->getTableFromDB($invoicesq);
			
			$paymentsq = " select * from ".$rodb->prefix."transactions where customer_id='".$_REQUEST['customerid']."' and user_id='".getBusinessId()."' order by dt asc, transaction_id asc ";
			$payments = $dblink->getTableFromDB($paymentsq);
			
			$returnsq = " select * from ".$rodb->prefix."sale_return where customerid='".$_REQUEST['customerid']."' and userid='".getBusinessId()."' order by dt asc, rtno asc, id asc ";
			$returns = $dblink->getTableFromDB($returnsq);
			
			$purchaseq = " select *, id buy_id, buy_date dt from ".$rodb->prefix."buy where customer='".$_REQUEST['customerid']."' and userid='".getBusinessId()."' order by buy_date asc, id asc ";
			$purchases = $dblink->getTableFromDB($purchaseq);
			
			$ledger = $invoices;
			
			$j = 0;
			$i = count($invoices);
			while(isset($payments[$j])){
				$ledger[$i] = $payments[$j];
				$i++;
				$j++;
			}
			$j = 0;
			while(isset($returns[$j])){
				$ledger[$i] = $returns[$j];
				$i++;
				$j++;
			}
			$j = 0;
			while(isset($purchases[$j])){
				$purchases[$j]['dt'] = $purchases[$j]['buy_date'];
				$ledger[$i] = $purchases[$j];
				$i++;
				$j++;
			}
			if(isset($ledger) && count($ledger) > 0)
			{
				usort($ledger, "compare_date_byrtno");
				usort($ledger, "compare_date");
			}
			if(isset($ledger) && count($ledger) > 0)
			{
				$ledger_all = $ledger;
				$ledger = "";
				$class = 'bgcolor="#CCCCCC"';
				$i=0;
				if(isset($ledger_all) && is_array($ledger_all) && count($ledger_all) > 0)
				foreach($ledger_all as $ledger[$i]){
					if($class == 'bgcolor="#CCCCCC"'){
						$class = '';
					}else{
						$class = 'bgcolor="#CCCCCC"';
					}
					$ledger_date = $ledger[$i]['dt'];
					$ledger[$i]['dt'] = @date("d M, Y", strtotime($ledger[$i]['dt']));
					if(isset($ledger[$i]['returnno']) && $ledger[$i]['returnno'] != ''){
						//if($ledger[$i]['gTotal'] == '' || $returns[$i]['gTotal'] == 0){echo "0";}else{echo round($returns[$i]['gTotal'],2);}
						$current_balance -= $returns[$i]['gTotal'];
					?>
					<tr <?php echo $class?>>
						<td width="186" align="left">&nbsp;<strong><?php echo $ledger[$i]['dt']?></strong></td>
						<td width="204" align="left">&nbsp;<strong><?php echo "<a href='".$ledger[$i]['returnno']."'>return# ".$ledger[$i]['returnno']."</a>"; ?></strong></td>
						<td width="204" align="left">&nbsp;<strong><?php echo $ledger[$i]['fileno'] ?></strong></td>
						<td width="175" align="left">&nbsp;<strong><?php 
						if($returns[$i]['gTotal'] < 0){
							echo round(-$returns[$i]['gTotal'], 2);
						}else{
							echo '0';
						}
						?></strong></td>
						<td>&nbsp;<?php 
						if($returns[$i]['gTotal'] > 0){
							echo round($returns[$i]['gTotal'], 2);
						}else{
							echo '0';
						}
						?></td>
						<td>&nbsp;<?php echo round($current_balance,2);?></td>
					</tr>
					<?php
							if($returns[$i]['gTotal'] > 0){
								$total_debit += 0;
								$total_credit += $returns[$i]['gTotal'];
							}else{
								$total_debit += (-$returns[$i]['gTotal']);
								$total_credit += 0;
							}
						}else if(isset($ledger[$i]['rtno']) && $ledger[$i]['rtno'] != ''){
							//if($ledger[$i]['gTotal'] == '' || $ledger[$i]['gTotal'] == 0){echo "0";}else{echo round($ledger[$i]['gTotal'],2);}
							$current_balance += $ledger[$i]['gTotal'];
					?>
					<tr <?php echo $class?>>
						<td width="186" align="left">&nbsp;<strong><?php echo $ledger[$i]['dt']?></strong></td>
						<td width="204" align="left">&nbsp;<strong><?php echo "<a href='".getPageUrl("find_bill")."&rtno=".$ledger[$i]['rtno']."&find_bill=Find' target='_blank'>Bill# ".$ledger[$i]['rtno']."</a>";?></strong></td>
						<td width="204" align="left">&nbsp;<strong><?php echo (isset($ledger[$i]['fileno']))?$ledger[$i]['fileno']:'' ?></strong></td>
						<td>&nbsp;<?php 
						if($ledger[$i]['gTotal'] > 0){
							echo round($ledger[$i]['gTotal'],2);
						}else{
							echo "0";
						}
						?></td>
						<td>&nbsp;<?php 
						if($ledger[$i]['gTotal'] < 0){
							echo round(-$ledger[$i]['gTotal'],2);
						}else{
							echo "0";
						}
						?></td>
						<td>&nbsp;<?php echo round($current_balance,2);?></td>
					</tr>
					<?php
							if($ledger[$i]['gTotal'] < 0){
								$total_debit += 0;
								$total_credit += (-$ledger[$i]['gTotal']);
							}else{
								$total_debit += $ledger[$i]['gTotal'];
								$total_credit += 0;
							}
						}else if(isset($ledger[$i]['buy_id']) && $ledger[$i]['buy_id'] != ''){
							//if($ledger[$i]['total'] == '' || $ledger[$i]['total'] == 0){echo "0";}else{echo round($ledger[$i]['total'],2);}
							$current_balance -= $ledger[$i]['total'];
					?>
					<tr <?php echo $class?>>
						<td width="186" align="left">&nbsp;<strong><?php echo $ledger[$i]['dt']?></strong></td>
						<td width="204" align="left">&nbsp;<strong><a href="<?php echo getPageUrl("find_purchase")."&rtno=".$ledger[$i]['buy_id'];?>" target="_blank">Purchase# <?php echo $ledger[$i]['buy_id'];?></a></strong></td>
						<td width="204" align="left">&nbsp;<strong><?php echo $ledger[$i]['fileno'] ?></strong></td>
						<td>&nbsp;<?php
						if($ledger[$i]['total'] < 0){
							echo round(-$ledger[$i]['total'],2);
						}else{
							echo '0';
						}
						?></td>
						<td>&nbsp;<?php
						if($ledger[$i]['total'] > 0){
							echo round($ledger[$i]['total'],2);
						}else{
							echo '0';
						}
						?></td>
						<td>&nbsp;<?php echo round($current_balance,2);?></td>
					</tr>
					<?php
							if($ledger[$i]['total'] < 0){
								$total_debit += (-$ledger[$i]['total']);
								$total_credit += 0;
							}else{
								$total_debit += 0;
								$total_credit += $ledger[$i]['total'];
							}
						}else if(isset($ledger[$i]['payment']) && $ledger[$i]['payment'] != ''){
							//if($ledger[$i]['payment'] == '' || $ledger[$i]['payment'] == 0){echo "0";}else{echo round($ledger[$i]['payment'],2);}
							$current_balance -= $ledger[$i]['payment'];
					?>
					<tr <?php echo $class?>>
						<td width="186" align="left">&nbsp;<strong><?php echo (isset($ledger[$i]['dt']))?$ledger[$i]['dt']:''?></strong></td>
						<td width="204" align="left">&nbsp;<strong><?php echo (isset($ledger[$i]['desc']))?$ledger[$i]['desc']:'';?></strong></td>
						<td width="204" align="left">&nbsp;<strong><?php echo (isset($ledger[$i]['fileno']))?$ledger[$i]['fileno']:'' ?></strong></td>
						<td width="175" align="left">&nbsp;<strong><?php 
						if($ledger[$i]['payment'] < 0){
							echo round(-$ledger[$i]['payment'], 2);
						}else{
							echo '0';
						}
						?></strong></td>
						<td>&nbsp;<strong><?php 
							if($ledger[$i]['payment'] > 0){
								echo round($ledger[$i]['payment'], 2);
							}else{
								echo '0';
							}
						?></strong></td>
						<td>&nbsp;<?php echo round($current_balance,2);?></td>
					</tr>
					<?php
							if($ledger[$i]['payment'] < 0){
								$total_debit += (-$ledger[$i]['payment']);
								$total_credit += 0;
							}else{
								$total_debit += 0;
								$total_credit += $ledger[$i]['payment'];
							}
						}
						?>
				<?php
					$cb_id = $dblink->getCellFromDB("select cb_id from ".$rodb->prefix."customer_balance where cb_userid = '".getBusinessId()."' and cb_customerid = '".$_REQUEST['customerid']."' and cb_date = '$ledger_date'");
					if($cb_id > 0){
						$update_ledger_q = "update ".$rodb->prefix."customer_balance set cb_balance = '$current_balance' where cb_userid = '".getBusinessId()."' and cb_customerid = '".$_REQUEST['customerid']."' and cb_date = '$ledger_date'";
						$rodb->execute($update_ledger_q);
					}else{
						$data = "(cb_userid, cb_customerid, cb_balance, cb_date) values ('".getBusinessId()."', '".$_REQUEST['customerid']."', '$current_balance', '$ledger_date')";
						$rodb->writeToDB($data, $rodb->prefix."customer_balance");
					}

					$update_current_balance_q = "update ".$rodb->prefix."customers set current_balance = '$current_balance' where user_id = '".getBusinessId()."' and customer_id = '".$_REQUEST['customerid']."'";
					$rodb->execute($update_current_balance_q);

					$i++;
					/*
					?>
					<tr>
						<th colspan="3" align="left">&nbsp;Total</th>
						<th align="left">&nbsp;<?php echo round($total_debit, 2);?></th>
						<th align="left">&nbsp;<?php echo round($total_credit, 2);?></th>
						<th align="left">&nbsp;</th>
					</tr>
					<?php
					*/
				}
			}
			?>
			<tr>
				<th colspan="3" align="left">&nbsp;Total</th>
				<th align="left">&nbsp;<?php echo round($total_debit, 2);?></th>
				<th align="left">&nbsp;<?php echo round($total_credit, 2);?></th>
				<th align="left">&nbsp;</th>
			</tr>
			</table>
		</td>
	</tr>
</table>