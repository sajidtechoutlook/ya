<?php
$_SESSION['orderid'] = getOrderID($_SESSION['orderid']);

foreach($create_bill_format_array[$_GET['performa']] as $item){
	$product = getProductByID(getBusinessId(), $item['product_id']);
	addToBill($_SESSION['orderid'], $item['product_id'], $product['sale_price'], getSaleDiscount($item['product_id']), $item['qty']);
}
?>
<meta http-equiv="refresh" content="0; url=<?php echo getPageUrl('sale_form')?>" />