<? 
	include"ro-config.php"; 
	//include"classes/db.php"; 
	//include"classes/functions.php"; 
	include "check.php";
	
	$start_date = $_REQUEST['fromyear']."-".$_REQUEST['frommonth']."-".$_REQUEST['fromday'];
	$end_date = $_REQUEST['toyear']."-".$_REQUEST['tomonth']."-".$_REQUEST['today'];
	
	$custinfo = $dblink->getTableFromDB(" select * from ".$rodb->prefix."customers where customer_id='".$_REQUEST['customerid']."' and user_id = '".getBusinessId()."'");
	$current_balance = $dblink->getCellFromDB(" select cb_balance from ".$rodb->prefix."customer_balance where cb_date = (select max(cb_date) from customer_balance where cb_date < '".$start_date."') ");
	if(!$current_balance>0){$current_balance=0;}
?>
  <table width="100%" align="center" border="1" style="border-collapse:collapse">
    <tr bgcolor="#EDE7EB">
      <td colspan="5" align="center"> <h1 style="color:#003366">"<?=$custinfo[0]['customer_name']?>" Ledger</h1> </td>
    </tr>
	<tr bgcolor="#F7F7F7" style="display: none">
		<td colspan="2">&nbsp;<strong>Opening_balance : <?=$current_balance;?></strong></td>
		<th colspan="3" align="center"><?=$start_date." &nbsp;&nbsp;&nbsp;<strong>TO</strong>&nbsp;&nbsp;&nbsp; ".$end_date?></th>
	</tr>
	<tr bgcolor="#CBFCBE">
	  <td width="186" align="left">&nbsp;<strong>Date</strong></td>
	  <td width="204" align="left">&nbsp;<strong>Description </strong></td>
	  <td width="175" align="left">&nbsp;<strong>Debit</strong></td>
	  <td width="183" align="left">&nbsp;<strong>Credit </strong></td>
	  <td width="207" align="left">&nbsp;<strong>Balance </strong></td>
	</tr>
	<?
	$invoicesq = " select * from ".$rodb->prefix."sale where customerid='".$_REQUEST['customerid']."' and userid='".getBusinessId()."' and dt between '".$start_date."' and '".$end_date."' order by dt asc ";
	$invoices = $dblink->getTableFromDB($invoicesq);
	
	$paymentsq = " select * from ".$rodb->prefix."transactions where customer_id='".$_REQUEST['customerid']."' and user_id='".getBusinessId()."' and dt between '".$start_date."' and '".$end_date."' order by dt asc ";
	$payments = $dblink->getTableFromDB($paymentsq);
	
	$returnsq = " select * from ".$rodb->prefix."sale_return where customerid='".$_REQUEST['customerid']."' and userid='".getBusinessId()."' and dt between '".$start_date."' and '".$end_date."' order by dt asc ";
	$returns = $dblink->getTableFromDB($returnsq);
/*	
	$i=0;
	$j=0;
	$k=0;
	while($invoices[$i])
	{
		if($invoices[$i]['dt'] >= $payments[$j]['dt'] && $payments[$j]['dt'] <= $returns[$k]['dt'] && $payments[$j]['dt']){
			echo "<br />j=".$payments[$j]['dt'].$j++;
		}else if($returns[$k]['dt'] <= $payments[$j]['dt'] && $invoices[$i]['dt'] >= $returns[$k]['dt'] && $returns[$k]['dt']){
			echo "<br />k=".$returns[$k]['dt'].$k++;
		}else{
			echo "<br />i=".$i++;
		}
	}
	exit;
*/
//	echo"<pre>";
//	print_r($invoices);
//	print_r($payments);
//	print_r($returns);
//	exit;
	
	if(isset($invoices[0]))
	{
		$i=0;
		$j=0;
		$k=0;
		while($invoices[$i])
		{
			if($payments[$j]['dt'] <= $invoices[$i]['dt'] && $payments[$j]['dt']){
				if($payments[$j]['dt'] >= $returns[$k]['dt'] && $returns[$k]['dt']){
					?>
					<tr>
						<td>&nbsp;<? echo $returns[$k]['dt']; //$returnsdt = explode(" ",$returns[$k]['dt']); echo $returnsdt[0]; ?></td>
						<td>&nbsp;Return # <?=$returns[$k]['returnno']."/".$returns[$k]['rtno']?></td>
						<td>&nbsp;0</td>
						<td>&nbsp;<? if($returns[$k]['gTotal'] == '' || $returns[$k]['gTotal'] == 0){echo "0";}else{echo round($returns[$k]['gTotal'],0);}
						$current_balance -= $returns[$k]['gTotal'];
						?></td>
						<td>&nbsp;<?=round($current_balance,0);?></td>
					</tr>
					<?
					$k++;
				}else{
			?>
				<tr>
					<td>&nbsp;<? echo $payments[$j]['dt']; //$pymtdt = explode(" ",$payments[$j]['dt']); echo $pymtdt[0]; ?></td>
					<td>&nbsp;<?=$payments[$j]['desc']?></td>
					<td>&nbsp;0</td>
					<td>&nbsp;<? if($payments[$j]['payment'] == '' || $payments[$j]['payment'] == 0){echo "0";}else{echo round($payments[$j]['payment'],0);}
					$current_balance -= $payments[$j]['payment'];
					?></td>
					<td>&nbsp;<?=round($current_balance,0);?></td>
				</tr>
			<?
					$j++;
				}
			}else if($returns[$k]['dt'] <= $invoices[$i]['dt'] && $returns[$k]['dt']){
				if($returns[$k]['dt'] >= $payments[$j]['dt'] && $payments[$j]['dt']){
			?>
				<tr>
					<td>&nbsp;<? echo $payments[$j]['dt']; //$pymtdt = explode(" ",$payments[$j]['dt']); echo $pymtdt[0]; ?></td>
					<td>&nbsp;<?=$payments[$j]['desc']?></td>
					<td>&nbsp;0</td>
					<td>&nbsp;<? if($payments[$j]['payment'] == '' || $payments[$j]['payment'] == 0){echo "0";}else{echo round($payments[$j]['payment'],0);}
					$current_balance -= $payments[$j]['payment'];
					?></td>
					<td>&nbsp;<?=round($current_balance,0);?></td>
				</tr>
			<?
					$j++;
				}else{
				?>
				<tr>
					<td>&nbsp;<? echo $returns[$k]['dt']; //$returnsdt = explode(" ",$returns[$k]['dt']); echo $returnsdt[0]; ?></td>
					<td>&nbsp;Return # <?=$returns[$k]['returnno']."/".$returns[$k]['rtno']?></td>
					<td>&nbsp;0</td>
					<td>&nbsp;<? if($returns[$k]['gTotal'] == '' || $returns[$k]['gTotal'] == 0){echo "0";}else{echo round($returns[$k]['gTotal'],0);}
					$current_balance -= $returns[$k]['gTotal'];
					?></td>
					<td>&nbsp;<?=round($current_balance,0);?></td>
				</tr>
				<?
					$k++;
				}
			}else{
			?>
				<tr>
					<td>&nbsp;<? echo $invoices[$i]['dt']; //$invdt = explode(" ",$invoices[$i]['dt']); echo $invdt[0]; ?></td>
					<td>&nbsp;Bill # <?=$invoices[$i]['rtno']?></td>
					<td>&nbsp;<? if($invoices[$i]['gTotal'] == '' || $invoices[$i]['gTotal'] == 0){echo "0";}else{echo round($invoices[$i]['gTotal'],0);}
					$current_balance += $invoices[$i]['gTotal'];
					?></td>
					<td>&nbsp;0</td>
					<td>&nbsp;<?=round($current_balance,0);?></td>
				</tr>
			<?
				$i++;
			}
		}
	}
	while($payments[$j])
	{
		if($returns[$k]['dt'] <= $payments[$j]['dt'] && isset($returns[$k]['dt'])){
				?>
				<tr>
					<td>&nbsp;<? echo $returns[$k]['dt']; //$returnsdt = explode(" ",$returns[$k]['dt']); echo $returnsdt[0]; ?></td>
					<td>&nbsp;Return # <?=$returns[$k]['returnno']."/".$returns[$k]['rtno']?></td>
					<td>&nbsp;0</td>
					<td>&nbsp;<? if($returns[$k]['gTotal'] == '' || $returns[$k]['gTotal'] == 0){echo "0";}else{echo round($returns[$k]['gTotal'],0);}
					$current_balance -= $returns[$k]['gTotal'];
					?></td>
					<td>&nbsp;<?=round($current_balance,0);?></td>
				</tr>
				<?
			$k++;
		}else{
			?>
				<tr>
					<td>&nbsp;<? echo $payments[$j]['dt']; //$pymtdt = explode(" ",$payments[$j]['dt']); echo $pymtdt[0]; ?></td>
					<td>&nbsp;<?=$payments[$j]['desc']?></td>
					<td>&nbsp;0</td>
					<td>&nbsp;<? if($payments[$j]['payment'] == '' || $payments[$j]['payment'] == 0){echo "0";}else{echo round($payments[$j]['payment'],0);}
					$current_balance -= $payments[$j]['payment'];
					?></td>
					<td>&nbsp;<?=round($current_balance,0);?></td>
				</tr>
			<?
			$j++;
		}
	}
	while($returns[$k]){
		?>
		<tr>
			<td>&nbsp;<? echo $returns[$k]['dt']; //$returnsdt = explode(" ",$returns[$k]['dt']); echo $returnsdt[0]; ?></td>
			<td>&nbsp;Return # <?=$returns[$k]['returnno']."/".$returns[$k]['rtno']?></td>
			<td>&nbsp;0</td>
			<td>&nbsp;<? if($returns[$k]['gTotal'] == '' || $returns[$k]['gTotal'] == 0){echo "0";}else{echo round($returns[$k]['gTotal'],0);}
			$current_balance -= $returns[$k]['gTotal'];
			?></td>
			<td>&nbsp;<?=round($current_balance,0);?></td>
		</tr>
		<?
		$k++;
	}
	?>
  </table>