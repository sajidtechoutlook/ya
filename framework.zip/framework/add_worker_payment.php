<?php
foreach($_REQUEST as $elementname=>$value)
    $params[$elementname] = stripslashes($value);

	$dt = $_POST['dt'];

	$values = "(`worker_id`, `amount`, `dt`)
        values
    ('".$_POST['worker_id']."', '".$_POST['payment']."', '".$_POST['dt']."')";
	$transaction = $rodb->writeToDB($values,
    $rodb->prefix."w_payment");
	
	/************************************************************************************/
	
	$productionq = "SELECT sum(p.sale_price*pp.qty) p_total, sum(pp.qty) pp_qty FROM 
	".$rodb->prefix."production_products pp
	inner join ".$rodb->prefix."product p
	on pp.productid = p.productid
	where production_id in (select id from ".$rodb->prefix."production where worker_id = '".$_POST['worker_id']."')
	and pp.dt <= '".$_POST['dt']."'
	";
	$production = $dblink->getRowFromDB($productionq);
	/*
	$prev_productionq = "SELECT sum(p.sale_price*pp.qty) p_total, sum(pp.qty) pp_qty FROM 
	".$rodb->prefix."production_products pp
	inner join ".$rodb->prefix."product p
	on pp.productid = p.productid
	where production_id in (select id from ".$rodb->prefix."production where worker_id = '".$_POST['worker_id']."')
	and pp.dt <= '".$start_date."'
	";
	$prev_production = $dblink->getRowFromDB($prev_productionq);
	*/
	
	$payments_q = "SELECT sum(amount) p_total FROM 
	".$rodb->prefix."w_payment wp
	where worker_id = '".$_POST['worker_id']."'
	and wp.dt <= '".$_POST['dt']."'";
	$payments = $dblink->getRowFromDB($payments_q);
	/*
	$prev_payments_q = "SELECT sum(amount) p_total FROM 
	".$rodb->prefix."w_payment wp
	where worker_id = '".$_POST['worker_id']."'
	and wp.dt <= '".$start_date."'";
	$prev_payments = $dblink->getRowFromDB($prev_payments_q);
	*/
	
	$baqya = ((isset($production['p_total']))?$production['p_total']:0) - ((isset($payments['p_total']))?$payments['p_total']:0);
	if($baqya > 0){
		$baqya = $baqya;
		$advance = 0;
	}else{
		$advance = -$baqya;
		$baqya = 0;
	}
	$message = "
Paid: ".$_POST['payment']." \n
Baqya: $baqya \n
Advance: $advance \n
	";
	$to_q = "select phone from user where uid = '".$_POST['worker_id']."'";
	$to = $rodb->getRowFromDB($to_q);
	$to = $to['phone'];
// echo
	$response = send_sms($to, $message);
	// die;
?>
<meta http-equiv="refresh" content="0;url=<?php echo getPageUrl("worker_payment")?>&amp;msg=Payment Added Successfully!" />