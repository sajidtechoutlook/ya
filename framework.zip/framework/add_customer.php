<?
	session_start(); 
	include "ro-config.php";
	//include "classes/db.php";
	include "check.php";
	
	foreach($_REQUEST as $elementname=>$value)
	{
		$params[$elementname] = stripslashes($value);
	}
	$err = $dblink->writeToDB("
	(customer_name ,
	ct_id,
	user_id,
	opening_balance,
	current_balance,
	customer_address,
	customer_phone,
	contact_person,
	dt
	)
	values
	('".$params['customername']."',
	'".$_REQUEST['ct_id']."',
	'".getBusinessId()."',
	'".$params['balance']."',
	'".$params['balance']."',
	'".$params['address']."',
	'".$params['phone']."',
	'".$params['contact_person']."',
	'". date("Y-m-d h:i:s") ."')
	",$rodb->prefix."customers");
?>
<meta http-equiv="refresh" content="0;url=manage_customers.php?msg=Customer Added Successfully!" />