<?php
// session_start();
//include "ro-config.php";
//include "ro-includes/db.php";
include "check.php";
foreach($_REQUEST as $elementname=>$value)
    $params[$elementname] = stripslashes($value);
if(isSuperAdmin()){
	$dt = _getDBDateTime($_POST['dt']).' '.@date('H:i:s');
}
if($dt == '') $dt = date("Y-m-d H:i:s");

/*$err = $dblink->writeToDB("(`customer_id`,`user_id`,`payment`,`desc`,`dt`)values('".$_REQUEST['customername_from']."','".getBusinessId()."','".$_REQUEST['payment']."','".$_REQUEST['desc']."','".$dt."')",$rodb->prefix."transactions");$dblink->updateInDB("current_balance=current_balance-".$_REQUEST['payment'],"customer_id='".$_REQUEST['customername_from']."'",$rodb->prefix."customers");$current_balance = $dblink->getCellFromDB("select current_balance from ".$rodb->prefix."customers where customer_id='".$_REQUEST['customername_from']."'");$dblink->writeToDB(" (cb_userid,cb_customerid,cb_balance,cb_date) values ('".getBusinessId()."','".$_REQUEST['customername_from']."','".$current_balance."','".$dt."') ",$rodb->prefix."customer_balance");*/

if(!empty($_REQUEST['customername_from']) or !empty($_REQUEST['billno_from'])){
	if(empty($_REQUEST['customername_from'])){
		$_REQUEST['customername_from'] = getCustomerIDByBill($_REQUEST['billno_from']);
	}
	$sale_id = getSaleIDFromRTNO($_REQUEST['billno_from']);
	make_transaction(getBusinessId(), $_REQUEST['customername_from'], $_REQUEST['payment'], $_REQUEST['desc'], $dt, $sale_id);
	makeCustomerLedger($_REQUEST['customername_from']);
}

if(!empty($_REQUEST['customername_to']) or !empty($_REQUEST['billno_to'])){
	if(empty($_REQUEST['customername_to'])){
		$_REQUEST['customername_to'] = getCustomerIDByBill($_REQUEST['billno_to']);
	}
	$sale_id = getSaleIDFromRTNO($_REQUEST['billno_to']);
	make_transaction(getBusinessId(), $_REQUEST['customername_to'], -$_REQUEST['payment'], $_REQUEST['desc'], $dt, $sale_id);
	makeCustomerLedger($_REQUEST['customername_to']);
}
?>
<meta http-equiv="refresh" content="0;url=<?php echo getPageUrl("manage_transactions")?>&amp;msg=Payment Added Successfully!" />