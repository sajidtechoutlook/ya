<? 
	if($_REQUEST['fromyear']==''){$_REQUEST['fromyear']=date("Y");}
	if($_REQUEST['frommonth']==''){$_REQUEST['frommonth']=date("m");}
	if($_REQUEST['fromday']==''){$_REQUEST['fromday']=1;}
	if($_REQUEST['toyear']==''){$_REQUEST['toyear']=date("Y");}
	if($_REQUEST['tomonth']==''){$_REQUEST['tomonth']=date("m");}
	if($_REQUEST['today']==''){$_REQUEST['today']=31;}
?>
  <table width="100%" align="center" border="1" style="border-collapse:collapse">
    <tr bgcolor="#EDE7EB">
      <td colspan="4" align="center"> <h1 style="color:#003366">Cash in Hand Report </h1> </td>
    </tr>
	<form action="" method="post">
	<!--<tr bgcolor="#F9F7F7">
		<td align="center" colspan="4"><select name="customer_id"><option value="0">All Customers</option><? $dblink->generateComboListing("customer_name","customer_id",$rodb->prefix."customers","user_id='".getBusinessId()."'",$_REQUEST['customer_id']); ?></select></td>
	</tr>-->
	<tr bgcolor="#F9F7F7">
		<td colspan="4" align="center">
			<strong>From </strong>&nbsp;&nbsp;&nbsp;
				<select name="fromyear">
					<?
					$next_year = date('Y')+1;
					for($i=2000;$i<$next_year;$i++)
					{
					?>
					<option value="<? if($i<10){$j="0".$i;}else{$j=$i;} echo $j; ?>" <? if($_REQUEST['fromyear']==$j){echo " selected";}?>><?=$i?></option>
					<?
					}
					?>
				</select> - 
				<select name="frommonth">
					<?
					for($i=1;$i<13;$i++)
					{
					?>
					<option value="<? if($i<10){$j="0".$i;}else{$j=$i;} echo $j; ?>" <? if($_REQUEST['frommonth']==$j){echo " selected";}?>><?=$i?></option>
					<?
					}
					?>
				</select> - 
				<select name="fromday">
				<?
					for($i=1;$i<32;$i++)
					{
					?>
					<option value="<? if($i<10){$j="0".$i;}else{$j=$i;} echo $j; ?>" <? if($_REQUEST['fromday']==$j){echo " selected";}?>><?=$i?></option>
					<?
					}
					?>
				</select> 
					&nbsp;&nbsp;&nbsp;<strong>To</strong> &nbsp;&nbsp;&nbsp;
				<select name="toyear">
					<?
					$next_year = date('Y')+1;
					for($i=2000;$i<$next_year;$i++)
					{
					?>
					<option value="<? if($i<10){$j="0".$i;}else{$j=$i;} echo $j; ?>" <? if($_REQUEST['toyear']==$j){echo " selected";}?>><?=$i?></option>
					<?
					}
					?>
				</select> - 
				<select name="tomonth">
					<?
					for($i=1;$i<13;$i++)
					{
					?>
					<option value="<? if($i<10){$j="0".$i;}else{$j=$i;} echo $j; ?>" <? if($_REQUEST['tomonth']==$j){echo " selected";}?>><?=$i?></option>
					<?
					}
					?>
				</select> - 
				<select name="today">
				<?
					for($i=1;$i<32;$i++)
					{
					?>
					<option value="<? if($i<10){$j="0".$i;}else{$j=$i;} echo $j; ?>" <? if($_REQUEST['today']==$j){echo " selected";}?>><?=$i?></option>
					<?
					}
					?>
				</select> 
				<input type="submit" name="generate" value="Generate" />
		</td>
	</tr>
	</form>
	
  </table>
  <?php
  if($_POST['generate'] != ''){
  ?>
  <table width="886" align="center" border="1" style="border-collapse:collapse">
    <tr bgcolor="#CBFCBE">
	  <td width="186" align="center"><strong>Receivings</strong></td>
	  <td width="187" align="center"><strong>Purchases + Expenditures</strong></td>
	  <td width="192" align="center"><strong>Profit</strong></td>
	</tr>
    <tr bgcolor="#CBFCBE">
	  <td width="186" align="center">
	  	<?php 
		$q = "select sum(payment) pmt from ".$rodb->prefix."transactions where user_id='".getBusinessId()."' and dt between '".$_POST['fromyear'].'-'.$_POST['frommonth'].'-'.$_POST['fromday']."' and '".$_POST['toyear'].'-'.$_POST['tomonth'].'-'.$_POST['today']."'";
		echo number_format($receivings = $rodb->getCellFromDB($q), 0, '.', ''); ?>
	  </td>
	  <td width="187" align="center">
	  	<?php 
		$q = "select sum(amount) pmt from ".$rodb->prefix."expenditures where userid='".getBusinessId()."' and dt between '".$_POST['fromyear'].'-'.$_POST['frommonth'].'-'.$_POST['fromday']."' and '".$_POST['toyear'].'-'.$_POST['tomonth'].'-'.$_POST['today']."'";
		$expenditures = $rodb->getCellFromDB($q);
		$q = "select sum(gTotal) pmt from ".$rodb->prefix."sale where userid='".getBusinessId()."' and dt between '".$_POST['fromyear'].'-'.$_POST['frommonth'].'-'.$_POST['fromday']."' and '".$_POST['toyear'].'-'.$_POST['tomonth'].'-'.$_POST['today']."'";
		$sales = $rodb->getCellFromDB($q);
		$outgoings = $sales+$expenditures;
		echo number_format($outgoings, 0, '.', '');
		
		?>
	  </td>
	  <td width="187" align="center">
	  	<?php 
			echo number_format($receivings - $outgoings, 0, '.', '');
		?>
	  </td>
	</tr>
  </table>
  <?php
  }
  ?>