<?php 	
//include "header.php"; 

if(!empty($_POST['licence_key'])){
    $licence_key = $_POST['licence_key'];
    if(isLicenceRegistered($licence_key)){
        activateMe(bas64_decode(bas64_decode(bas64_decode($licence_key))));
        ?>
            You have successfully activated the software.
            <meta http-equiv="refresh" content="2; login.php" />
        <?php
    }
}
$url = "http://www.pegham-e-haq.com/admin/get_youaccounts_licence.php?mac=".getMac();
//$url = "https://example.com/path/for/soap/url/";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HEADER, 0);
$data = curl_exec($ch);
curl_close($ch);
?>
	<form action="" name="mp_form" method="post">
  <table width="100%" align="center" border="1" style="border-collapse:collapse">
    <tr bgcolor="#EDE7EB">
      <td align="center" colspan="3"> <h1 style="color:#003366">Please enter licence key</h1> </td>
    </tr>
	<tr bgcolor="#F9F7F7">
		<td align="center">
                    <input type="text" name="licence_key" value="<?php echo $data?>" /></td>
		<td align="left">
                    <input type="submit" name="" value="Activate" />
		</td>
	</tr>
  </table>
	</form>
<?php //include"footer.php"; ?>