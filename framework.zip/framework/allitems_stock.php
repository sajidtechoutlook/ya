<?php 
if(!isset($_GET['id'])) $_GET['id'] = 0;
$current_balance = 0;
$rodb->prefix = 'ro_0_';
$product_id_q = "select productid from ".$rodb->prefix."product where userid = '".getBusinessId()."' and productid > '".$rodb->mysql_real_escape_string($_GET['id'])."' order by productid asc limit 1";
$_GET['id'] = $rodb->getCellFromDB($product_id_q);

if(!isset($_GET['id']) || $_GET['id'] == '0' || $_GET['id'] == ''){
	echo "All Products Stock updated.";
	die;
}
$product_id = $rodb->mysql_real_escape_string($_GET['id']);
//echo 
$sales_q = "SELECT s.dt dt, s.*, sp.* FROM `".$rodb->prefix."sale_products` sp inner join ".$rodb->prefix."sale s 
on sp.sale_id = s.id
and sp.productid = '".$product_id."'
and s.rtno != '0'
order by s.dt asc
";
$all_sales = $rodb->getTableFromDB($sales_q);
//var_dump($all_sales);
//echo
$purchases_q = "SELECT b.buy_date dt, b.*, bp.* FROM `".$rodb->prefix."buy_products` bp inner join ".$rodb->prefix."buy b 
on bp.buy_id = b.id
and bp.product_id = '".$product_id."'
order by b.buy_date asc
";
$all_purchases = $rodb->getTableFromDB($purchases_q);
//var_dump($all_purchases);

$items = ro_array_merge($all_sales, $all_purchases);
//var_dump($items);
//die;
function sortByOrder($a, $b) {
    return $a['dt'] > $b['dt'];
}
if(isset($items) && is_array($items))
usort($items, 'sortByOrder');
?>
<table border="1" bordercolor="#CCCCCC" cellpadding="0" cellspacing="0" width="100%" align="center" style="border-collapse:collapse">
	<tr>
		<td align="center">
			<?php 
			$q_item_name = "SELECT concat(tc.tc_name, '-', cat.cat_name, '-', p.productname) p_name FROM `".$rodb->prefix."product` p 
inner join `".$rodb->prefix."category` cat on cat.cat_id = p.cat_id
inner join `".$rodb->prefix."top_category` tc on tc.tc_id = cat.cat_tc_id
WHERE productid='".$_GET['id']."'";
			echo '<h1>'.$rodb->getCellFromDB($q_item_name).'</h1>';
			?>
		</td>
	</tr>
	<tr>
		<td>
			<table width="100%" align="center" border="0" cellpadding="1" cellspacing="1">
			<tr bgcolor="#999999">
			  <td width="186" align="left">&nbsp;<strong style="color:#993300">Date</strong></td>
			  <td width="204" align="left">&nbsp;<strong style="color:#993300">Description </strong></td>
			  <td width="175" align="left">&nbsp;<strong style="color:#993300">In</strong></td>
			  <td width="183" align="left">&nbsp;<strong style="color:#993300">Out </strong></td>
			  <td width="207" align="left">&nbsp;<strong style="color:#993300">Balance </strong></td>
			</tr>
			<?php
			$rodb->updateInDB("stock='0'", "productid='".$product_id."'", $rodb->prefix."product");
			if(isset($items) && is_array($items) && count($items) > 0){
				$total_qty_packs = 0;

				foreach($items as $item){
					$item['qty'] = (isset($item['qty']))?$item['qty']:0;
					$item['quantity'] = (isset($item['quantity']))?$item['quantity']:0;
					?>
					<tr <?php echo (isset($class))?$class:""?>>
						<td width="186" align="left">&nbsp;<strong><?php echo _retDate($item['dt']);?></strong></td>
						<td width="204" align="left">&nbsp;
						<?php if($item['qty'] > $item['quantity']){?>
							<a href="<?php echo getPageUrl("find_bill")."&rtno=".$item['rtno'];?>" target="_blank">Sale# <?php echo $item['rtno'];?></a>
						<?php }else{ ?>
							<a href="<?php echo getPageUrl("find_purchase")."&rtno=".$item['buy_id'];?>" target="_blank">Purchase# <?php echo $item['buy_id'];?></a>
						<?php } ?>
						</td>
						<td>&nbsp;<?php echo $item['quantity'];
						if(getFlag_packs_quantity()){
							if($item['qty'] <= $item['quantity']){
								echo ' / Packs = '.$item['qty_packs'];
								$total_qty_packs += $item['qty_packs'];
							}
						}
						?></td>
						<td width="204" align="left">&nbsp;<?php echo $item['qty'];
						if(getFlag_packs_quantity()){
							if($item['qty'] > $item['quantity']){
								echo ' / Packs = '.$item['qty_packs'];
								$total_qty_packs -= $item['qty_packs'];
							}
						}
						?></td>
						<td>&nbsp;<?php echo $current_balance += $item['quantity']-$item['qty'];
							if(getFlag_packs_quantity()){
								echo ' / Packs = '.$total_qty_packs;
							}
						?></td>
					</tr>
					<?php
					$rodb->updateInDB("stock='".$current_balance."'", "productid='".$product_id."'", $rodb->prefix."product");
				}
			}
			?>
			</table>
		</td>
	</tr>
</table>
<meta http-equiv="refresh" content="0; url=<?php echo getPageUrl('allitems_stock').'&id='.$product_id?>" />