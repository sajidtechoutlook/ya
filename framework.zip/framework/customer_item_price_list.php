<?php
$customer_id = $rodb->mysql_real_escape_string($_GET['customer_id']);
$product_id = $rodb->mysql_real_escape_string($_GET['product_id']);

$q = "SELECT 

s.rtno rtno, sp.productid, tc.tc_name, c.cat_name, p.productname, sp.sale_price, s.dt dt, cust.customer_name

FROM `".$rodb->prefix."sale` s inner join ".$rodb->prefix."sale_products sp on s.id = sp.sale_id 
inner join ".$rodb->prefix."product p on p.productid = sp.productid
inner join ".$rodb->prefix."customers cust on s.customerid = cust.customer_id
where s.customerid = '$customer_id' 
and sp.productid = '$product_id'
group by s.id order by s.dt desc";
$price_list = $rodb->getTableFromDB($q);
?>
<table width="100%" border="1" style="border-collapse: collapse">
	<tr><td colspan="3" align="center"><h1><?php echo (isset($price_list[0]['customer_name']))?$price_list[0]['customer_name']:''?></h1></td></tr>
	<tr><td colspan='3' align='center'><?php echo (isset($price_list[0]['productname']))?$price_list[0]['productname']:'';?></td></tr>
	<tr><td><h2>Item</h2></td><td><h2>Date</h2></td><td><h2>Price</h2></td><td><h2>Date</h2></td></tr>
	<?php 
	if(isset($price_list) && is_array($price_list) && count($price_list) > 0)
		foreach($price_list as $price){
		?>
		<tr>
			<td><a href="<?php echo getPageURL('find_bill').'&rtno='.$price['rtno'];?>">Bill# <?php echo $price['rtno'];?></a></td>
			<td><?php echo _retDate($price['dt']);?></td>
			<td><?php echo $price['sale_price']?></td>
			<td><?php echo _retDate($price['dt']);?></td>
		</tr>
		<?php
		}
	?>
</table>