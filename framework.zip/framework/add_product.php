<?
	session_start();
	include "ro-config.php";
	//include "classes/db.php";
	include "check.php";
	
	foreach($_REQUEST as $elementname=>$value){
		$params[$elementname] = stripslashes($value);
	}
	
	$err = $dblink->writeToDB("
	(productname ,
	unit ,
	price ,
	purchase_price ,
	sale_price ,
	sequence,
	cat_id,
	userid)
	values
	('".$params['productname']."',
	'".$params['unit']."',
	'".$params['price']."',
	'".$params['purchase_price']."',
	'".$params['sale_price']."',
	'".$params['sequence']."',
	'".$params['catid']."',
	'".getBusinessId()."')
	",$rodb->prefix."product");
	
	if( isset($err[0]) && $err[0]!='' ){?><meta http-equiv="refresh" content="0;url=manage_products.php?msg=Item Not Added!" /><? }
	else{
	?><meta http-equiv="refresh" content="0;url=manage_products.php?msg=Item Added Successfully!&catid=<?=$_REQUEST['catid']?>" /><?
	}
?>