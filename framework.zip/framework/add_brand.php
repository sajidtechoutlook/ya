<? 	
	session_start(); 
	include "ro-config.php";
//	include "classes/db.php";
	include "check.php";
	
	foreach($_REQUEST as $elementname=>$value)
	{
		$params[$elementname] = stripslashes($value);
	}
	
	$err = $dblink->writeToDB("
	(cat_name ,
	cat_tc_id ,
	user_id)
	values
	('".$params['brandname']."',
	'".$params['tc_id']."',
	'".getBusinessId()."')
	",$rodb->prefix."category");
?>
<meta http-equiv="refresh" content="0;url=manage_brands.php?msg=Brand Added Successfully!" />