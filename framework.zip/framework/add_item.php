<?
	session_start(); 
	include "ro-config.php";
//	include "classes/db.php";
	include "check.php";
	
	foreach($_REQUEST as $elementname=>$value)
	{
		$params[$elementname] = stripslashes($value);
	}
	$err = $dblink->writeToDB("
	(tc_name ,
	tc_user_id,
	dt
	)
	values
	(
	'".$_REQUEST['tc_name']."',
	'".getBusinessId()."',
	'". date("Y-m-d h:i:s") ."')
	",$rodb->prefix."top_category");
?>
<meta http-equiv="refresh" content="0;url=manage_items.php?msg=Item Added Successfully!" />