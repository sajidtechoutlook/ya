<?
	session_start(); 
	include "classes/config.php";
	include "classes/db.php";
	include "check.php";
	
	foreach($_REQUEST as $elementname=>$value)
	{
		$params[$elementname] = stripslashes($value);
	}
	$err = $dblink->writeToDB("
	(ct_name ,
	user_id,
	dt
	)
	values
	(
	'".$_REQUEST['ct_name']."',
	'".getBusinessId()."',
	'". date("Y-m-d h:i:s") ."')
	",$rodb->prefix."customer_type");
?>
<meta http-equiv="refresh" content="0;url=manage_sectors.php?msg=Sector Added Successfully!" />