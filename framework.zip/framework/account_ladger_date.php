<?
	if($_REQUEST['fromyear']==''){$_REQUEST['fromyear']=date("Y");}
	if($_REQUEST['frommonth']==''){$_REQUEST['frommonth']=date("m");}
	if($_REQUEST['fromday']==''){$_REQUEST['fromday']=1;}
	if($_REQUEST['toyear']==''){$_REQUEST['toyear']=date("Y");}
	if($_REQUEST['tomonth']==''){$_REQUEST['tomonth']=date("m");}
	if($_REQUEST['today']==''){$_REQUEST['today']=31;}
?>
<form action="account_ladger.php" method="post">
<input type="hidden" name="customerid" value="<?=$_REQUEST['customerid']?>" />
<table width="100%" align="center" border="1" style="border-collapse:collapse">
	<tr bgcolor="#F9F7F7">
		<td colspan="4" align="center">
			<strong>From </strong>&nbsp;&nbsp;&nbsp;
				<select name="fromyear">
					<option value="2008">2008</option>
					<option value="2009" <? if($_REQUEST['fromyear']=='2009'){echo "selected";} ?>>2009</option>
					<option value="2010" <? if($_REQUEST['fromyear']=='2010'){echo "selected";} ?>>20100</option>
				</select> - 
				<select name="frommonth">
					<?
					for($i=1;$i<13;$i++)
					{
					?>
					<option value="<? if($i<10){$j="0".$i;}else{$j=$i;} echo $j; ?>" <? if($_REQUEST['frommonth']==$j){echo " selected";}?>><?=$i?></option>
					<?
					}
					?>
				</select> - 
				<select name="fromday">
				<?
					for($i=1;$i<32;$i++)
					{
					?>
					<option value="<? if($i<10){$j="0".$i;}else{$j=$i;} echo $j; ?>" <? if($_REQUEST['fromday']==$j){echo " selected";}?>><?=$i?></option>
					<?
					}
					?>
				</select> 
					&nbsp;&nbsp;&nbsp;<strong>To</strong> &nbsp;&nbsp;&nbsp;
				<select name="toyear">
					<option value="2008">2008</option>
					<option value="2009" <? if($_REQUEST['toyear']=='2009'){echo "selected";} ?>>2009</option>
					<option value="2010" <? if($_REQUEST['toyear']=='2010'){echo "selected";} ?>>2010</option>
				</select> - 
				<select name="tomonth">
					<?
					for($i=1;$i<13;$i++)
					{
					?>
					<option value="<? if($i<10){$j="0".$i;}else{$j=$i;} echo $j; ?>" <? if($_REQUEST['tomonth']==$j){echo " selected";}?>><?=$i?></option>
					<?
					}
					?>
				</select> - 
				<select name="today">
				<?
					for($i=1;$i<32;$i++)
					{
					?>
					<option value="<? if($i<10){$j="0".$i;}else{$j=$i;} echo $j; ?>" <? if($_REQUEST['today']==$j){echo " selected";}?>><?=$i?></option>
					<?
					}
					?>
				</select> 
				<input type="submit" value="Generate" />
		</td>
	</tr>
  </table>
</form>