<? 	
	if($_REQUEST['fromyear']==''){$_REQUEST['fromyear']=date("Y");}
	if($_REQUEST['frommonth']==''){$_REQUEST['frommonth']=date("m");}
	if($_REQUEST['fromday']==''){$_REQUEST['fromday']=1;}
	if($_REQUEST['toyear']==''){$_REQUEST['toyear']=date("Y");}
	if($_REQUEST['tomonth']==''){$_REQUEST['tomonth']=date("m");}
	if($_REQUEST['today']==''){$_REQUEST['today']=31;}
        $to_date = $_REQUEST['toyear']."-".$_REQUEST['tomonth']."-".$_REQUEST['today'];
        $from_date = $_REQUEST['fromyear']."-".$_REQUEST['frommonth']."-".$_REQUEST['fromday'];
?>
  <table width="886" align="center" border="1" style="border-collapse:collapse">
    <tr bgcolor="#EDE7EB">
      <td colspan="6" align="center"> 
			<form action="<?=getPageUrl("credit_list")?>" method="post">
		<table width="100%" align="center" border="0">
			<tr bgcolor="#EDE7EB">
			  <td colspan="4" align="center"> <h1 style="color:#003366">Credit List</h1> </td>
			</tr>
			<tr bgcolor="#F9F7F7">
				<td colspan="4" align="center">
					<strong>From </strong>&nbsp;&nbsp;&nbsp;
						<select name="fromyear">
							<?
							$next_year = date('Y')+1;
							for($i=2000;$i<$next_year;$i++)
							{
							?>
							<option value="<? if($i<10){$j="0".$i;}else{$j=$i;} echo $j; ?>" <? if($_REQUEST['fromyear']==$j){echo " selected";}?>><?=$i?></option>
							<?
							}
							?>
						</select> - 
						<select name="frommonth">
							<?
							for($i=1;$i<13;$i++)
							{
							?>
							<option value="<? if($i<10){$j="0".$i;}else{$j=$i;} echo $j; ?>" <? if($_REQUEST['frommonth']==$j){echo " selected";}?>><?=$i?></option>
							<?
							}
							?>
						</select> - 
						<select name="fromday">
						<?
							for($i=1;$i<32;$i++)
							{
							?>
							<option value="<? if($i<10){$j="0".$i;}else{$j=$i;} echo $j; ?>" <? if($_REQUEST['fromday']==$j){echo " selected";}?>><?=$i?></option>
							<?
							}
							?>
						</select> 
							&nbsp;&nbsp;&nbsp;<strong>To</strong> &nbsp;&nbsp;&nbsp;
						<select name="toyear">
							<?
							$next_year = date('Y')+1;
							for($i=2000;$i<$next_year;$i++)
							{
							?>
							<option value="<? if($i<10){$j="0".$i;}else{$j=$i;} echo $j; ?>" <? if($_REQUEST['toyear']==$j){echo " selected";}?>><?=$i?></option>
							<?
							}
							?>
						</select> - 
						<select name="tomonth">
							<?
							for($i=1;$i<13;$i++)
							{
							?>
							<option value="<? if($i<10){$j="0".$i;}else{$j=$i;} echo $j; ?>" <? if($_REQUEST['tomonth']==$j){echo " selected";}?>><?=$i?></option>
							<?
							}
							?>
						</select> - 
						<select name="today">
						<?
							for($i=1;$i<32;$i++)
							{
							?>
							<option value="<? if($i<10){$j="0".$i;}else{$j=$i;} echo $j; ?>" <? if($_REQUEST['today']==$j){echo " selected";}?>><?=$i?></option>
							<?
							}
							?>
						</select> 
						<input type="submit" name="generate" value="Generate" />
				</td>
			</tr>
			
		  </table>
			</form>
	  </td>
    </tr>
	<?php
	if($_POST['generate'] != ''){
	?>
	<tr bgcolor="#CBFCBE">
	  <td width="186" align="left" style="padding-left:5px;"><strong>Buyer</strong></td>
	  <td width="187" align="left" style="padding-left:5px;"><strong>Opening Balance</strong></td>
	  <td width="207" align="right" style="padding-right:5px;"><strong>Total Sale</strong></td>
	  <td width="207" align="right" style="padding-right:5px;"><strong>Total Payment</strong></td>
	  <td width="207" align="right" style="padding-right:5px;"><strong>Pending CHQ</strong></td>
	  <td width="207" align="right" style="padding-right:5px;"><strong>Sale Return</strong></td>
	  <td width="207" align="right" style="padding-right:5px;"><strong>Closing Balance</strong></td>
	</tr>
		<?
		$q = " SELECT customerid, sum(gTotal) gTotal FROM `".$rodb->prefix."sale` 

WHERE `dt` >= '".$from_date."' and `dt` <= '".$to_date."'

group by customerid";
		$allCustomers = $dblink->getTableFromDB($q);
		if(isset($allCustomers[0]))
		{
			$i=0;
			while($allCustomers[$i])
			{
                            $opening_balance_q = "SELECT cb_balance FROM `".$rodb->prefix."customer_balance` WHERE cb_customerid ='".$allCustomers[$i]['customerid']."' AND cb_date < '".$from_date."' ORDER BY cb_date DESC LIMIT 1";
                            $opening_balance = $rodb->getCellFromDB($opening_balance_q);
                            if($opening_balance == 0) $opening_balance = 0;
                            
                            $total_payments_q = "SELECT sum(payment) FROM `".$rodb->prefix."transactions` where customer_id = '".$allCustomers[$i]['customerid']."' and dt between '".$from_date."' and '".$to_date."'";
                            $total_payments = $rodb->getCellFromDB($total_payments_q);
                            if($total_payments == 0) $total_payments = 0;
                            
                            $total_returns_q = "SELECT sum(gTotal) FROM `".$rodb->prefix."sale_return` where customerid = '".$allCustomers[$i]['customerid']."' and dt between '".$from_date."' and '".$to_date."'";
                            $total_returns = $rodb->getCellFromDB($total_returns_q);
                            if($total_returns == 0) $total_returns = 0;
                            
                            $closing_balance = 0;
                            $closing_balance = $opening_balance + $allCustomers[$i]['gTotal'] - $total_payments;
			?>
				<tr>
					<td align="left" style="padding-left:5px;"><?=$allCustomers[$i]['customerid']?></td>
					<td align="left" style="padding-left:5px;"><?=$opening_balance?></td>
					<td align="left" style="padding-left:5px;"><?=$allCustomers[$i]['gTotal']?></td>
                                        <td align="left" style="padding-left:5px;"><?=$total_payments?></td>
                                        <td align="left" style="padding-left:5px;"></td>
                                        <td align="left" style="padding-left:5px;"><?=$total_returns?></td>
                                        <td align="left" style="padding-left:5px;"><?=$closing_balance?></td>
				</tr>
				<?
				$i++;
			}
		}
	}
	?>
	<tr>
		<td colspan="2" align="center" style="padding-right:5px;"><strong>Total</strong></td>
		<td align="right" style="padding-right:5px;"><strong><?php echo $total_credit?></strong></td>
		<td align="right" style="padding-right:5px;"><strong><?php echo $total_debit?></strong></td>
	</tr>
  </table>