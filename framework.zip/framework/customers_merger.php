<?php
$q = "select * from ".$rodb->prefix."customer_type ct
inner join ".$rodb->prefix."city c on c.city_ct_id = ct.ct_id
inner join ".$rodb->prefix."customers cust on cust.customer_city_id = c.city_id
";
$customers = $rodb->getTableFromDB($q);

if(isset($customers) && is_array($customers) && count($customers) > 0){
    foreach($customers as $customer){
        $q = "update ".$rodb->prefix."customers set customer_name='".$customer['ct_name'].'-'.$customer['city_name'].'-'.$customer['customer_name']."' 
        where customer_id = '".$customer['customer_id']."'";
        ;

        $rodb->execute($q);
    }
    $q_rename_customer_type = "RENAME TABLE `".$rodb->prefix."customer_type` TO `".$rodb->prefix."customer_type_tbd`;";
    $q_rename_city = "RENAME TABLE `".$rodb->prefix."city` TO `".$rodb->prefix."city_tbd`;";

    $rodb->execute($q_rename_customer_type);
    $rodb->execute($q_rename_city);
}