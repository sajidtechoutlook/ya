<? include "header.php"; ?>
	<form id="form1" name="form1" method="post" action="login.php">
		<table align="center" style="font-family:'Courier New', Courier, monospace; color:#000066">
			<tr>
				<td>Username</td>
				<td><input name="username" type="text" width="15" /></td>
			</tr>
			<tr>
				<td>Password</td>
				<td><input name="password" type="password" width="15" /></td>
			</tr>
			<tr>
				<td colspan="2" align="center">
					<input name="" type="submit" value="Login!" style="font-family:Verdana, Arial, Helvetica, sans-serif;" />
					<input name="Input" type="reset" value="Clear Form!" style="font-family:Verdana, Arial, Helvetica, sans-serif;" />
				</td>
			</tr>
		</table>
	</form>
<? include "footer.php"; ?>