            </td>



        <td align="left" valign="top" width="13">&nbsp;</td>

      </tr>

      <tr>

        <td colspan="3" align="left" valign="top"><table align="center" border="0" cellpadding="0" cellspacing="0" width="100%">

          <tbody><tr>

            

        <td align="left" bgcolor="#ff0000" valign="top" width="17"><!--<img src="<? themeUrl()?>/images/bottom_left.jpg" height="40" width="17">--></td>

            

                  <td align="center" bgcolor="#ff0000" valign="middle" width="100%">&copy; <?php echo @date("Y");?> All rights reserved. Powered by <a href="http://www.youaccounts.com">YouAccounts</a></span></td>

            <td align="right" bgcolor="#ff0000" valign="top" width="17"><!--<img src="<? themeUrl()?>/images/bottom_right.jpg" alt="rabta Online" height="40" width="17">--></td>

          </tr>

        </tbody></table></td>

      </tr></tbody></table></td>

</tr> </tbody></table> 

<script type="text/javascript">
	$.ajax({
	  url: "http://youaccounts.com/commercials/index.php",
	  context: document.body
	}).done(function(data) {
	  $( '#commercials' ).html( data );
	});
</script>

</body></html>