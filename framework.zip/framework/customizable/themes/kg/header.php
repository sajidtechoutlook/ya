<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>You Accounts</title>
	<!-- General Website files start -->

	<script language="javascript" src="<? themeUrl()?>scripts/scriptw.js"></script>
	<link href="<? themeUrl()?>images/global.css" rel="stylesheet" type="text/css">
	<!-- General Website files end -->
	<!-- Calendar Files srtart -->
	<script type="text/javascript" src="<? themeUrl()?>js/jquery.js"></script>
	<script type="text/javascript" src="<? themeUrl()?>js/jquery-ui.js"></script>
	<script type="text/javascript" src="<? themeUrl()?>js/jquery-calendar.js"></script>
	
	<link rel="stylesheet" type="text/css" href="<? themeUrl()?>css/jquery-calendar.css">
	<link rel="stylesheet" type="text/css" href="<? themeUrl()?>css/styles.css">
	<!-- Calendar Files end -->
	<!-- Top bar menu files start -->

	<link href="<? themeUrl()?>css/style.css" type="text/css" rel="stylesheet">
	<link href="<? themeUrl()?>css/ddlevelsmenu-base.css" type="text/css" rel="stylesheet">
	<link href="<? themeUrl()?>css/ddlevelsmenu-topbar.css" type="text/css" rel="stylesheet">
<link rel="stylesheet" href="<? themeUrl()?>css/jquery-ui.css">

	<script src="<? themeUrl()?>js/mouseover.js" type="text/javascript" language="javascript"></script>
	<script src="<? themeUrl()?>js/AC_RunActiveContent.js" type="text/javascript" language="javascript"></script>
	<script src="<? themeUrl()?>js/ddlevelsmenu.js" type="text/javascript" language="javascript"></script>
	




	<link rel="stylesheet" href="<? themeUrl()?>css/menu-style.css" type="text/css" media="screen, projection"/>
    <!--[if lte IE 7]>
        <link rel="stylesheet" type="text/css" href="css/ie.css" media="screen" />
    <![endif]-->
    		
	<!--<script type="text/javascript" src="<? themeUrl()?>js/jquery-1.3.1.min.js"></script>-->	
	<script type="text/javascript" language="javascript" src="<? themeUrl()?>js/hoverIntent.js"></script>
	<script type="text/javascript" language="javascript" src="<? themeUrl()?>js/jquery.dropdown.js"></script>
	<!-- Top bar menu files end -->
	<style type="text/css">
	<!--
	body {
		background-color: #fff;
		margin-left: 0px;
		margin-top: 0px;
		margin-right: 0px;
		margin-bottom: 0px;
	}
	.border {
		border: 1px solid #000000;
	}
	a href{
	color:#00CC00;
	}
	-->
	</style>
</head>
<body onload="<?=$onloadBody?>">
<table border="0" cellpadding="0" cellspacing="0" width="100%">

  <tbody>
	<?php if(roGetSession('trial')){
		  ?>
			<tr>
				<td align="center" colspan="3">
				<div id="commercials"></div>
				</td>
			</tr>
		  <?php
	  }?>
  <tr>
    <td align="center" valign="top"><table border="0" cellpadding="0" cellspacing="0" width="100%">
      <tbody>
      <tr>
        <td colspan="3" align="left" bgcolor="#ff0000" height="43" valign="middle"><table border="0" cellpadding="0" cellspacing="0" width="100%">
          <tbody><tr>
            <td width="4%">&nbsp;</td>
            <td width="25%"><a href="?page=sale_form"><strong><font color="#CCCC00" size="+1"><?=$logoname1?></font> <font color="#FFFFFF" size="+1"><?=$logoname2?></font></strong></a></td>
            <td class="toplinks" align="right" valign="middle">
				<div align="left">
				<? if(getBusinessId() != ''){
				$top_menu = getMenu();
				?>
				<ul class="dropdown">
						<?php
						$i = 1;
						foreach($top_menu as $menu_item){
						?>
						<li><a href="<?=$menu_item['url']?>"><?=$menu_item['text']?></a>
						<? if( !empty($menu_item['sub_menu']) ){ ?>
						<ul class="sub_menu">
							<? foreach($menu_item['sub_menu'] as $sub_menu){ ?>
							<li><a href="<?=$sub_menu['url']?>"><?=$sub_menu['text']?></a></li>
							
							<? } ?>
						</ul>
						<?
							}
							$i++;
						?>
						</li>
						<?php
						}
						?>
					</ul>
				<? } ?>
				</div>
			</td>
          </tr>
        </tbody></table>
      </td>
      </tr>
      <tr>
        
      <td align="left" valign="top" width="14">&nbsp;</td>
          
          <td class="bodybg" align="left" bgcolor="#ffffff" valign="top" width="100%" height="500">