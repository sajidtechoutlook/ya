<?php

include('models/expenditure.php');

include('expenditure_controller_class.php');

/*

addMenuItem(array("url" => "new_expenditure.php", "text" => "Expenditure", "sub_menu" => array(

	0 => array("id" => "expenditure", "url" => $webUrl."?page=new_expenditure", "text"=>" Expenditure"),

	1 => array("id" => "expenditure_report", "url" => $webUrl."?page=new_expenditure&type=report", "text"=>" Expenditure report")

)));

*/

function expenditure(){
	global $expenditureModel, $expenditureController, $rodb;
	if( isset($_GET['type']) && $_GET['type']=='report' ){
            if(empty($_POST['start_date']))$_POST['start_date'] = date('1-m-Y 00:00');
            if(empty($_POST['end_date']))$_POST['end_date'] = date('d-m-Y 23:59');
            $condition = " dt between '"._getDBDate($_POST['start_date'])."' and '"._getDBDate($_POST['end_date'])." 23:59:59' and userid='".getBusinessId()."'";
            $data['expenditures'] = $expenditureModel->getFilteredExpenditures($condition);
            include('views/expenditure_report.php');
	}else{
		if( isset($_POST['expenditure_form_action']) && $_POST['expenditure_form_action'] == 'save' ){
			$expenditureModel->saveExpenditure();
		}
		include('views/expenditure.php');
	}
}

?>