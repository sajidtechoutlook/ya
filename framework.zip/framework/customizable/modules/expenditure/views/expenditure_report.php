<link href="<?php echo getModuleURL("expenditure");?>views/style.css" rel="stylesheet" type="text/css">

<table align="center" class="Tb3">

	<tr>

		<td colspan="5" align="center">

			<strong style="font-size:24px; color:#000066; font-family:'Courier New', Courier, monospace">Expenditure Report</strong><br /><br /><br /><font color="#FF0000"><?php echo (isset($_REQUEST['msg']))?$_REQUEST['msg']:''?></font>

		</td>

	</tr>

	<tr>

		<td width="100%" align="center">

			<form id="new_expenditure" name="new_expenditure" method="post" action="">

			<input type="hidden" name="expenditure_report_action" value="generate" />

				<table class="TB3">

					<tr>

						<td></td><td><input id="start_date" name="start_date" value="<?php if(!empty($_POST['start_date'])) echo $_POST['start_date'];else echo _getUserFriendlyNowDateTime('01-m-Y 00:00:00');?>" class="datepicker" /></td>

						<td></td><td><input id="end_date" name="end_date" value="<?php if(!empty($_POST['end_date']))echo $_POST['end_date'];else echo _getUserFriendlyNowDateTime('d-m-Y 23:59:59');?>" class="datepicker" /></td>

						<td><input type="submit" class="btn btn-brand" name="generate" id="generate" value="Generate" /></td>

					</tr>

				</table>

			</form>

		</td>

	</tr>

	<tr>

		<td>

			<table class="main_tbl_listing" border="0" cellpadding="5" cellspacing="0" width="100%">

				<?php

				if( !empty($data['expenditures']) ){

				?>

					<tr class="tbl_listing_heading">

						<td width="14%"><strong>Date</strong></td>

						<td width="71%"><strong>Description</strong></td>

						<td width="15%"><strong>Amount</strong></td>

						<td><?php if(isSuperAdmin()){ ?>Actions<?php } ?></td>
					</tr>

				<?php

					$total = 0;
					$class = '';

					foreach( $data['expenditures'] as $row ){

						$class = $expenditureController->getAlternateListingClass($class);

				?>

					<tr <?php echo $class?>>

						<td><?php echo _retDate($row['dt'])?></td>

						<td><?php echo $row['description']?></td>

						<td><?php echo $row['amount']; $total += $row['amount'];?></td>
						
						<td><?php if(isSuperAdmin()){ ?><a href="javascript:;" onclick="if(confirm('Do you really want to delete this expense?')) window.location='<?php echo getPageUrl("delete")?>&type=expense&id=<?php echo $row['id']?>';">Delete</a><?php } ?></td>

					</tr>

				<?php

					}

				?>

					<tr><td colspan="3"><hr /></td></tr>

					<tr <?php echo $class?>>

						<th align="right" colspan="2">Total: &nbsp;&nbsp;&nbsp;</th>

						<td>  <?php echo $total?></td>

					</tr>

				<?php

				}else{

					echo "No Expenditure Found.";

				}

				?>

			</table>

		</td>

	</tr>

</table>

<script>

    // $( function() {

    //     var $sd = $( "#start_date" ).val( );

    //     var $ed = $( "#end_date" ).val( );

        

    //     $( "#start_date" ).datepicker( );

    //     $( "#start_date" ).datepicker( "option", "dateFormat", "dd-mm-yy" );

        

    //     $( "#end_date" ).datepicker( );

    //     $( "#end_date" ).datepicker( "option", "dateFormat", "dd-mm-yy" );

        

    //     $( "#start_date" ).val($sd);

    //     $( "#end_date" ).val($ed);

    // } );

</script>