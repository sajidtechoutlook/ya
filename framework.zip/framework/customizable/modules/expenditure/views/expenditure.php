<table align="center" class="Tb3">

	<tr>

		<td colspan="5" align="center">

			<strong style="font-size:24px; color:#000066; font-family:'Courier New', Courier, monospace">New Expenditure</strong><br /><br /><br /><font color="#FF0000"><?php echo (isset($_REQUEST['msg']))?$_REQUEST['msg']:''?></font>

		</td>

	</tr>

	<tr>

      <td colspan="5" width="100%" align="center">

		<form id="new_expenditure" name="new_expenditure" method="post" action="">

		<input type="hidden" name="expenditure_form_action" value="save" />

			<table class="Tb3">

				<tr>

					<td align="left">Date</td>

					<td align="left">

						<input type="text" name="dt" id="dt" value="<?php echo date('d-m-Y')?>" class="datepicker" />

					</td>

				</tr>

				<tr>

					<td align="left">Total Amount</td>

					<td align="left">

						<input type="text" name="amount" id="amount" class="" />

					</td>

				</tr>

				<tr>

					<td align="left">Description</td>

					<td align="left">

						<textarea name="description" id="description" cols="45" rows="9"></textarea>

					</td>

				</tr>

				<tr>

					<td align="left"></td>

					<td align="left">

						<input type="submit" name="save" value="Save" />

					</td>

				</tr>

			</table>

		</form>

	  </td>

	</tr>

</table>
<script>

    // $( function() {
    //     var $sd = $( "#dt" ).val( );
    //     $( "#dt" ).datepicker( );
    //     $( "#dt" ).datepicker( "option", "dateFormat", "dd-mm-yy" );
    //     $( "#dt" ).val($sd);
		
	// 	$('#amount').focus();
    // } );

</script>