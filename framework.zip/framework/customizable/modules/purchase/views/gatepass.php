<table align="center" class="Tb3">
	<tr>
		<td colspan="5" align="center">
			<strong style="font-size:24px; color:#000066; font-family:'Courier New', Courier, monospace">Gate Pass In</strong><br /><br /><br /><font color="#FF0000"><?php echo $_REQUEST['msg']?></font>
		</td>
	</tr>
	<tr>
		<td colspan="5" width="100%">
                    <form action="" method="post" enctype="multipart/form-data">
			Gatepass File: <input type="file" name="gatepass_file" />
                        <input type="submit" name="" value="Upload" />
                    </form>
		</td>
	</tr>
	<tr>
      <td colspan="5" width="100%">
	<form id="new_purchase" name="new_purchase" method="post" action="">
	<input type="hidden" name="purchase_form_action" value="update" />
        <input type="hidden" id="product" name="product" value="<?php echo $_REQUEST['product']?>" />
        <input type="hidden" id="customer_id" name="customer_id" value="<?php echo $_REQUEST['customer_id']?>" />
		<table class="Tb3">
			<tr>
				<td colspan="5">
					<table align="center">
						<tr style="font-weight:300">
							<td><strong>Item</strong></td>
							<td><strong>Quantity</strong></td>
							<td><strong>Available Stock</strong></td>
						</tr>
						<tr>
							<td id="product_block">
                                                            <input type="text" id="product_search" name="product_search" value="<?php if($_REQUEST['purchase_form_action'] != 'add') echo $_POST['product_search']?>" placeholder="Product Name" />
							</td>
							<td><input type="text" name="qty" value="1" /></td>
							<td style="color:#FF0000">(<?php echo $rodb->getAvailableStock($_POST['product'],getBusinessId());?>)</td>
							<td align="left">
								<input type="button" name="addtobill" value="Add to Bill" onclick="document.new_purchase.purchase_form_action.value='add';document.new_purchase.submit();" />							</td>
						</tr>
					</table>				</td>
			</tr>
			<tr>
                            <td align="left" colspan="3"><strong>Gate Pass From:</strong>
                                    <input type="text" id="customer_search" name="customer_search" value="<?php echo $_POST['customer_search']?>" placeholder="Gate Pass From" />
                            </td>
                            <td colspan="2" align="right">
                                <span><strong>Date: </strong><input type="text" name="dt" id="dt" value="<?php echo $_POST['dt']; ?>" />
                                <?php if($_POST['dt']==''){ ?><script type="text/javascript">
                                        var d = new Date();
                                        var curr_secs	= d.getSeconds();
                                        var curr_min 	= d.getMinutes();
                                        var curr_hour 	= d.getHours();
                                        var curr_date 	= d.getDate();
                                        var curr_month	= d.getMonth()+1;
                                        var curr_year	= d.getFullYear();
                                        if(curr_month < 10){
                                                curr_month = '0'+curr_month;
                                        }
                                        var dtm = curr_year+'-'+curr_month+'-'+curr_date+' '+curr_hour+':'+curr_min+':'+curr_secs;
                                        document.getElementById('dt').value = dtm;
                                </script>
                                <?php } ?>
                                </span>
                                <br />
                                <span><strong>Ref: Gate Pass #</strong>
                                <input type="text" name="fileno" value="<?php echo $_SESSION['ses_fileno']?>" /></span>
                            </td>
			</tr>
			<tr bgcolor="#D1FDCC">
                            <th>Item</th>
                            <th>Brand</th>
                            <th>Size</th>
                            <th>Quantity</th>
                            <th>Action</th>
			</tr>
			<?php
				$order_products = $purchaseModel->getPurchaseCart();
				$i=0;
				if( count($order_products) > 0 )
				foreach($order_products as $product)
				{
			?>
				<tr <?php echo $class=$purchaseController->getAlternateListingClass($class);?>>
					<td align="left"><?php echo $product['tc_name']?></td>
					<td align="left"><?php echo $product['cat_name']?></td>
					<td align="left"><?php echo $product['productname']?></td>
					<td align="left"><?php echo $product['quantity']?></td>
					<td align="center"><a href="#" onclick="if(confirm('Are You Sure To Delete?')){window.location='?page=new_purchase&action=delete&amp;product_id=<?php echo $product['product_id']?>';}"><img src="<?php echo getURL('template')?>img/b_drop.png" alt="delete" border="0" /></a></td>
				</tr>
			<?php
					$total_quantity += $product['quantity'];
					$i++;
				}
			?>
			<tr bgcolor="#D1FDCC"><td colspan="3" align="right"><strong>Total &nbsp;&nbsp;&nbsp;</strong></td>
				<td colspan="2"><strong id="Total"> <?php echo round($total_quantity,2);?> </strong></td>
			</tr>
			<tr bgcolor="#D1FDCC">
				<td colspan="5" align="center">
					<input type="submit" name="update" value="Update" />
					<input type="button" value="Save Gate Pass" onclick="if(confirm('Save The Invoice?')){document.new_purchase.purchase_form_action.value='save';document.new_purchase.submit();}" />				</td>
			</tr>
		</table>
	</form>
	  </td>
	</tr>
</table>
<script type="text/javascript">
$('#product_search').focus();
$(function() {
var products = [
    <?php $products = $rodb->getProducts(getBusinessId());
if(count($products) > 0)
foreach($products as $product){
    echo '{
value: "'.$product['tc'].'-'.$product['cat_name'].'-'.$product['productname'].'",
label: "'.$product['tc'].'-'.$product['cat_name'].'-'.$product['productname'].'",
desc: "'.$product['tc'].'-'.$product['cat_name'].'-'.$product['productname'].'",
id: '.$product['productid'].'},';
}
?>
];
$( "#product_search" ).autocomplete({
minLength: 0,
source: products,
focus: function( event, ui ) {
$( "#product_search" ).val( ui.item.label );
$( "#product" ).val( ui.item.id );
return false;
},
select: function( event, ui ) {
$( "#product_search" ).val( ui.item.label );
$( "#product" ).val( ui.item.id );
document.new_purchase.submit();
return false;
}
})
.data( "ui-autocomplete" )._renderItem = function( ul, item ) {
return $( "<li>" )
.append( "<a>" + item.label + "</a>" )
.appendTo( ul );
};

var customers = [
    <?php $customers = $rodb->getCustomers(getBusinessId());
if(count($customers) > 0)
foreach($customers as $customer){
    echo '{
value: "'.$customer['ct'].'-'.$customer['city_name'].'-'.$customer['customer_name'].'",
label: "'.$customer['ct'].'-'.$customer['city_name'].'-'.$customer['customer_name'].'",
desc: "'.$customer['ct'].'-'.$customer['city_name'].'-'.$customer['customer_name'].'",
id: '.$customer['customer_id'].'},';
}
?>
];
$( "#customer_search" ).autocomplete({
minLength: 0,
source: customers,
focus: function( event, ui ) {
$( "#customer_search" ).val( ui.item.label );
$( "#customer_id" ).val( ui.item.id );
return false;
},
select: function( event, ui ) {
$( "#customer_search" ).val( ui.item.label );
$( "#customer_id" ).val( ui.item.id );
return false;
}
})
.data( "ui-autocomplete" )._renderItem = function( ul, item ) {
return $( "<li>" )
.append( "<a>" + item.label + "</a>" )
.appendTo( ul );
};

});
</script>