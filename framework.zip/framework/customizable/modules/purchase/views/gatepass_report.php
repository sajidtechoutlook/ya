<link href="<? echo getModuleURL("purchase");?>views/style.css" rel="stylesheet" type="text/css">
<script type="text/javascript">
//<![CDATA[
	$(document).ready(function (){
//		$("#start_date").calendar();
//		$("#end_date").calendar();
//			$("#calendar1_alert").click(function(){alert(popUpCal.parseDate($('#calendar1').val()))});
	});
//]]>

	function productPurchaseReport(pid){
		$('#productid').val( pid );
		document.new_purchase.submit();
	}
</script>
<table align="center" class="Tb3">
	<tr>
		<td colspan="5" align="center">
			<strong style="font-size:24px; color:#000066; font-family:'Courier New', Courier, monospace">Gatepass In report</strong><br /><br /><br /><font color="#FF0000"><?=$_REQUEST['msg']?></font>
		</td>
	</tr>
	<tr>
		<td width="100%" align="center">
			<form id="new_purchase" name="new_purchase" method="post" action="">
			<input type="hidden" name="purchase_report_action" value="generate" />
			<input type="hidden" id="productid" name="productid" value="" />
				<table class="TB3">
					<tr>
						<td><strong>Start Date:</strong></td><td><input type="start_date" id="start_date" name="start_date" value="<?=$_POST['start_date']?>" /></td>
						<td><strong>End Date:</strong></td><td><input type="end_date" id="end_date" name="end_date" value="<?=$_POST['end_date']?>" /></td>
						<td><input type="submit" class="btn_submit" name="generate" id="generate" value="Generate" /></td>
					</tr>
				</table>
			</form>
		</td>
	</tr>
	<? 
	//if( $_POST['purchase_report_action']=='generate' )	{ 
	?>
	<tr>
		<td>
			<table class="main_tbl_listing" border="0" cellpadding="5" cellspacing="0">
				<?
				if( !empty($data['purchases']) ){
				?>
					<tr class="tbl_listing_heading">
						<td>Date</td>						<td>Description</td>						<td>Total</td>
					</tr>
				<?					foreach( $data['purchases'] as $row ){
						$class = $purchaseController->getAlternateListingClass($class);
				?>					<tr <?=$class?>>
						<td><?=_retDate($row['buy_date']);?></td>						<td><a href="<?php echo getPageUrl('find_purchase').'&rtno='.$row['id'];?>"><?=$row['id'];?></a></td>						<td><?=$row['total']?></td>
					</tr>
					<?
					}
				}else{
					echo "No Purchase Found.";
				}
				?>
			</table>
		</td>
	</tr>
	<? } ?>
</table>
<script>
    $( function() {
        var $sd = $( "#start_date" ).val( );
        var $ed = $( "#end_date" ).val( );
        
        $( "#start_date" ).datepicker( );
        $( "#start_date" ).datepicker( "option", "dateFormat", "dd-mm-yy" );
        
        $( "#end_date" ).datepicker( );
        $( "#end_date" ).datepicker( "option", "dateFormat", "dd-mm-yy" );
        
        $( "#start_date" ).val($sd);
        $( "#end_date" ).val($ed);
    } );
</script>