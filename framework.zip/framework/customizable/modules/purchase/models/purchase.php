<?php 

class Purchase{
	function Purchase(){
		@session_start();
		global $rodb;
		$this->tbl_buy = $rodb->prefix."buy";
		$this->tbl_buy_products = $rodb->prefix."buy_products";
	}
	function getPurchase($purchase_id){
		global $rodb;
		
		$q = "select * from ".$rodb->prefix."buy b inner join ".$rodb->prefix."buy_products bp
		on b.id = bp.buy_id
		where b.id = '$purchase_id'";
		return $bought = $rodb->getTableFromDB($q);
	}
	function addPurchaseInCart($product_id, $qty, $qty_packs, $price=0){
		global $rodb;
		$not_add = '';
		if( isset($_SESSION['ses_purchase_cart']) && count($_SESSION['ses_purchase_cart']) > 0 ){
			$i = 0;
			foreach($_SESSION['ses_purchase_cart'] as $pur_cart){
				$_SESSION['ses_purchase_cart_new'][$i] = $pur_cart;
				if( $pur_cart["product_id"] == $product_id ){
					
					$_SESSION['ses_purchase_cart_new'][$i]['quantity'] = $qty;
					$not_add = 'yes';
					// break;
				}
				$i++;
			}
			$_SESSION['ses_purchase_cart'] = $_SESSION['ses_purchase_cart_new'];
			unset($_SESSION['ses_purchase_cart_new']);
		}
		if($not_add != 'yes'){
			$_SESSION['ses_purchase_cart'] = (isset($_SESSION['ses_purchase_cart']))?$_SESSION['ses_purchase_cart']:array();
			$prd_info_q = "select * from ".$rodb->prefix."product where productid = '".$product_id."'";
			$prd_info = $rodb->getRowFromDB($prd_info_q);
			
			$_SESSION['ses_purchase_cart'][count($_SESSION['ses_purchase_cart'])] = array(
			 "product_id" => $product_id
			, "productname" => $prd_info['productname']
			, "quantity" => $qty
			, "qty_packs" => $qty_packs
			, "price" => $price
			);
		}
	}
	function getPurchaseCart(){
		return (isset($_SESSION['ses_purchase_cart']))?$_SESSION['ses_purchase_cart']:'';
	}
	function deletePurchaseFromCart($product_id){
		global $rodb;
		if( isset($_SESSION['ses_purchase_cart']) ){
			$i = 0;
			foreach($_SESSION['ses_purchase_cart'] as $ind => $pur_cart){
				if($pur_cart['product_id']==$product_id){
					unset($_SESSION['ses_purchase_cart'][$ind]);
					break;
				}
				$i++;
			}
		}
	}
	function updatePurchaseCart(){
		$_SESSION['ses_customer_id'] = (isset($_POST['customer_id'])?$_POST['customer_id']:((isset($_SESSION['ses_customer_id']))?$_SESSION['ses_customer_id']:0));
		$_SESSION['ses_fileno']		= (isset($_POST['fileno'])?$_POST['fileno']:((isset($_SESSION['ses_fileno']))?$_SESSION['ses_fileno']:''));
		$_SESSION['ses_gst']	= (isset($_POST['gst'])?$_POST['gst']:((isset($_SESSION['ses_gst']))?$_SESSION['ses_gst']:''));
		$_SESSION['ses_discount_amount']	= (isset($_POST['discount_amount'])?$_POST['discount_amount']:((isset($_SESSION['ses_discount_amount']))?$_SESSION['ses_discount_amount']:''));
		$_SESSION['ses_extra_charges_desc']= (isset($_POST['extra_charges_desc'])?$_POST['extra_charges_desc']:((isset($_SESSION['ses_extra_charges_desc']))?$_SESSION['ses_extra_charges_desc']:''));
		$_SESSION['ses_extra_charges_amount'] 	= (isset($_POST['extra_charges_amount'])?$_POST['extra_charges_amount']:(isset($_SESSION['extra_charges_amount']))?$_SESSION['extra_charges_amount']:'');
		$_SESSION['ses_discount_percent_check']	= (isset($_POST['discount_percent_check'])?$_POST['discount_percent_check']:((isset($_SESSION['ses_discount_percent_check']))?$_SESSION['ses_discount_percent_check']:''));
	}
	function updatePurchase($purchase_id){
		global $rodb;
		$purchase = $this->getPurchase($purchase_id);
		// echo '<pre>';
		// print_r($_REQUEST);
		// print_r($_SESSION);
		// die;
		if($_POST['total'] > 0){
			$rodb->updateInDB("total='".$_POST['total']."', buy_date='".$_POST['dt']."'", "id='".$purchase_id."'",$rodb->prefix."buy");
		}else{
			$rodb->updateInDB("buy_date='".$_POST['dt']."'", "id='".$purchase_id."'",$rodb->prefix."buy");
		}
		if(isset($_POST['customer_search']) && $_POST['customer_search'] != ''){
			$customer_id = createNewCustomer($_POST['customer_search']);
			$rodb->updateInDB("customer='".$customer_id."'", "id='".$purchase_id."'",$rodb->prefix."buy");
		}
		$rodb->updateInDB("buy_date='".$_POST['dt']."'", "buy_id='".$purchase_id."'",$rodb->prefix."buy_products");
		$purchase = $this->getPurchase($purchase_id);
		$this->removePurchaseProducts($purchase_id);
		if(isset($purchase) && count($purchase) > 0 && isset($purchase[0]['buy_date']))
		$this->savePurchaseProducts($purchase_id, $purchase[0]['buy_date']);
		$this->emptyPurchase();
	}
	function removePurchaseProducts($purchase_id){
		global $rodb;
		$q = "delete from ".$rodb->prefix."buy_products where buy_id = '".$purchase_id."'";
		$result = $rodb->Execute($q);
	}
	function savePurchase(){
		global $rodb;
		$dt = (isset($_POST['dt']))?$_POST['dt']:@date("Y-m-d H:i:s");
		 
		$buyQ = "Insert into ".$rodb->prefix."buy 
		( userid, total, customer, fileno, gst, discount_percent_check, discount_amount, extra_charges_desc, extra_charges_amount, buy_date )
		values
		(".$rodb->qstr(getBusinessId()).", ".$rodb->qstr($_POST['total']).", ".$rodb->qstr($_POST['customer_id']).", ".$rodb->qstr($_POST['fileno']).", ".$rodb->qstr($_POST['gst']).", ".((isset($_POST['discount_percent_check']))?$rodb->qstr($_POST['discount_percent_check']):"''").", ".$rodb->qstr($_POST['discount_amount']).", ".$rodb->qstr($_POST['extra_charges_desc']).", ".$rodb->qstr($_POST['extra_charges_amount']).", ".$rodb->qstr($dt).")
		";
		$result = $rodb->Execute($buyQ);
		$this->savePurchaseProducts($result[1], $dt);
		$this->manageRawProducts($result[1]);
		$this->updteCustomer($_POST['total']);
		$q_phoneno = "select customer_phone from ".$rodb->prefix."customers where user_id = '".getBusinessId()."' and customer_id='".$_POST['customer_id']."'";
		$phoneno = $rodb->getCellFromDB($q_phoneno);
		$msg = "Thanks for your products.
		Your Receipt# is: ".$result[1]. 
		", Total: ".$_POST['total'];
		send_sms($phoneno, $msg);
		$this->emptyPurchase();
		return $result[1];
	}
	function updteCustomer($gTotal = ''){
		global $rodb;
		$rodb->updateInDB("current_balance=current_balance-".$gTotal,"customer_id='".$_REQUEST['customer_id']."'",$rodb->prefix."customers");
		$current_balance = $rodb->getCellFromDB("select current_balance from ".$rodb->prefix."customers where customer_id='".$_REQUEST['customer_id']."'");
		$dt = @date('Y-m-d H:i:s');
		$rodb->writeToDB(" (cb_userid,cb_customerid,cb_balance,cb_date) values ('".getBusinessId()."','".$_REQUEST['customer_id']."','".$current_balance."','".$dt."') ",$rodb->prefix."customer_balance");
	}
	function savePurchaseProducts($buy_id, $dt){
		global $rodb;
		$buy_products_q = "Insert into ".$rodb->prefix."buy_products 
		( buy_id, product_id, buy_price, quantity, qty_packs, sub_total, buy_date )
		values";
		$i = 1;
		$c = count($_SESSION['ses_purchase_cart']);
		if(!empty($_SESSION['ses_purchase_cart'])){
			foreach($_SESSION['ses_purchase_cart'] as $product){
				$buy_products_q .= "( ".$rodb->qstr($buy_id).", ".$rodb->qstr($product['product_id']).", ".$rodb->qstr($product['price']).", ".$rodb->qstr($product['quantity']).", ".$rodb->qstr($product['qty_packs']).", ".$rodb->qstr($product['quantity']*$product['price']).", ".$rodb->qstr($dt)." )
				";
				if( ++$i <= $c ){
					$buy_products_q .= ",";
				}
				$this->manageStock($product['product_id'], $product['quantity']);
			}
		}
		$result = $rodb->Execute($buy_products_q);
	}
	function manageRawProducts($buy_id){
		global $rodb;
		$q = "select * from ".$rodb->prefix."buy b inner join ".$rodb->prefix."buy_products bp
		on b.id = bp.buy_id
		where b.id = '".$buy_id."'
		and b.userid = '".getBusinessId()."'
		";
		$buy = $rodb->getTableFromDB($q);
		if(is_array($buy) && count($buy) > 0)
		foreach($buy as $b){
			$raw_q = "select * from ".$rodb->prefix."product_raw_formulae 
			where fg_product_id = '".$b['product_id']."'
			";
			$raw = $rodb->getTableFromDB($raw_q);
			if(is_array($raw) && count($raw) > 0)
			foreach($raw as $r){
				if(!isset($sale_id)){
					$data = "
					(userid, worker_id, customerid, dt, rtno, fileno, total, gst, extrachargesdesc, extracharges, discount_desc, discountinpercent, discount, gTotal, status, is_gatepass, order_type, payment_type, synced, is_paid, kot_1, kot_2, is_edited)
					values
					('".getBusinessId()."', '".getBusinessId()."', '0', '".$b['buy_date']."', '".getNextSaleRTNO()."', 'Used in production for purchase# ".$buy_id."', 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0)
					";
					$sale_id = $rodb->writeToDB($data,$rodb->prefix."sale");
					$sale_id = $sale_id[1];
				}
				$data = "
				(productid,productname,cat_id,sale_price, sale_discount,qty,qty_packs,sale_id,userid)
				values
				('".$r['raw_product_id']."','".
				$rodb->getCellFromDB("select productname from ".$rodb->prefix."product where productid='".$r['raw_product_id']."'").
				"', '', '0', '0','".
				($b['quantity'] * $r['raw_product_qty'])
				."', '',
				'".$sale_id."', 
				'".getBusinessId()."')
				";
				$sale_products = $rodb->writeToDB($data,$rodb->prefix."sale_products");
			}
		}
	}
	function emptyPurchase(){
		unset($_SESSION['ses_purchase_cart']);
	}
	function getFilteredPurchases($condition=''){
		global $rodb;
		if($condition!='') $condition = " where ".$condition;
		$q = "select * from ".$this->tbl_buy_products.$condition;
		return $rodb->getTableFromDB($q);
	}
	function manageStock($product_id, $quantity){
		global $rodb;
		$dt = (isset($_REQUEST['dt']))?$rodb->mysql_real_escape_string($_REQUEST['dt']):@date('Y-m-d H:i:s');
		$err = $rodb->updateInDB(" stock=stock+".$quantity." ","productid='".$product_id."'",$rodb->prefix."product");
		$prd = $rodb->getTableFromDB("select * from ".$rodb->prefix."product where productid='".$product_id."'");
		$rodb->writeToDB("(ps_productid,ps_productname,ps_userid,ps_stock,ps_date) values (
		'".$prd[0]['productid']."',
		'".$prd[0]['productname']."',
		'".getBusinessId()."',
		'".$prd[0]['stock']."',
		'".$dt."'
		)",$rodb->prefix."product_stock");
	}
	function getProductBoughtBetween($product_id, $start_date, $end_date){
		global $rodb;
		$q = "
                select 
                        sum(quantity) ttl
                from 
                        ".$rodb->prefix."buy_products
                where 
                        product_id = '".$product_id."' 
                        and buy_date >= '$start_date'
                        and buy_date <= '$end_date'
                ";
		return $bought = $rodb->getCellFromDB($q);
	}
}
$purchaseModel = new Purchase();