<?php

include('models/purchase.php');
include('purchase_controller_class.php');
/*
addMenuItem(array("url" => "new_purchase.php", "text" => "Purchase", "sub_menu" => array(
	0 => array("id" => "purchase", "url" => $webUrl."?page=new_purchase", "text"=>" Purchase"),
	1 => array("id" => "purchase_report", "url" => $webUrl."?page=new_purchase&type=report", "text"=>" Purchase report")
)));
*/
function purchase(){
    global $purchaseModel, $purchaseController, $rodb;
    if(isset($_GET['type']) && $_GET['type']=='report'){
        $_POST['purchase_report_action'] = 'generate';
        if(empty($_POST['start_date'])) $_POST['start_date'] = @date('1-m-Y');
        if(empty($_POST['end_date'])) $_POST['end_date'] = @date('d-m-Y');
        if( $_POST['purchase_report_action']=='generate' ){
			if(isset($_GET['analysis']) && $_GET['analysis']=='yes'){
				$data['purchase_analysis'] = $purchaseController->getPurchaseAnalysis($_POST['start_date'], $_POST['end_date']);
			}elseif(isset($_GET['gatepass']) && $_GET['gatepass']=='yes'){
				$data['purchases'] = $purchaseController->getGatepasses($_POST['start_date'], $_POST['end_date']);
			}else{
				$data['purchases'] = $purchaseController->getPurchases($_POST['start_date'], $_POST['end_date']);
			}
        }
        if(!empty($_GET['productid'])){
            include('views/purchase_report_productwise.php');
        }elseif(isset($_GET['analysis']) && $_GET['analysis']=='yes'){
            include('views/purchase_analysis.php');
        }elseif(isset($_GET['gatepass']) && $_GET['gatepass'] == 'yes'){
            include('views/gatepass_report.php');
        }else{
            include('views/purchase_report.php');
        }
    }else{
        $_POST['qty_packs'] = (isset($_POST['qty_packs']))?$_POST['qty_packs']:0;
        if(isset($_POST['product_search'])){
            $_REQUEST['product'] = $_POST['product'] = createNewProduct($_POST['product_search'], $_POST['sale_price'], $_POST['price']);
        }
        if( isset($_POST['purchase_form_action']) && $_POST['purchase_form_action'] == 'add' ){
            if(!empty($_POST['product_barcode_search'])){
                $_POST['product'] = searchProductByBarcode($_POST['product_barcode_search']);
            }else{
                $_POST['product'] = createNewProduct($_POST['product_search'], $_POST['sale_price'], $_POST['price']);
            }
            if(isset($_POST['product']))
                $purchaseModel->addPurchaseInCart($_POST['product'], $_POST['qty'], $_POST['qty_packs'], $_POST['price']);
        }elseif( isset($_POST['purchase_form_action']) && $_POST['purchase_form_action'] == 'save' ){
			if(isset($_SESSION['ses_edit_purchase']) && $_SESSION['ses_edit_purchase'] > 0){
				$purchase_id = $_SESSION['ses_edit_purchase'];
				$purchaseModel->updatePurchase($purchase_id);
				unset($_SESSION['ses_edit_purchase']);
			}else{
                $purchase_id = $purchaseModel->savePurchase();
                if(isset($_GET['gatepass']) && $_GET['gatepass']=='in'){
					setGatePassIn($purchase_id);
					redirect(getPageUrl( "find_gatepass" ).'&rtno='.$purchase_id);
					die;
				}
            }
            redirect(getPageUrl( "find_purchase" ).'&rtno='.$purchase_id);
            die;
        }elseif(isset($_FILES['gatepass_file'])){
            $purchaseController->gatepass_in($_FILES['gatepass_file']);
            redirect();
        }
        if( isset($_GET['action']) && $_GET['action'] == 'delete' ){
            $purchaseModel->deletePurchaseFromCart($_GET['product_id']);
            redirect(getPageUrl( "new_purchase" ));
            die;
        }
        $purchaseModel->updatePurchaseCart();

        if(isset($_GET['gatepass']) && $_GET['gatepass']=='in')
            include('views/gatepass.php');
        else
            include('views/purchase.php');
    }
}