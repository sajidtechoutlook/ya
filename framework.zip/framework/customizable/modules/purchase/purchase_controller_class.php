<?php
class PurchaseController{
    function getPurchases($start_date = '', $end_date = ''){
		global $rodb, $purchaseModel;
        if($start_date!='')
            $condition = " buy_date >= '"._getDBDate($start_date)."' ";
        if($end_date!='')
            if($condition=='')
                $condition = " buy_date <= '"._getDBDate($end_date)."' 23:59:59 ";
            else
                $condition .= " and buy_date <= '"._getDBDate($end_date)." 23:59:59' ";
        $q = "select * from ".$rodb->prefix."buy
        where ".$condition." and userid = '".getBusinessId()."' order by buy_date asc
        ";
        return $all_purchases = $rodb->getTableFromDB($q);
	}
    function getGatePasses($start_date = '', $end_date = ''){
		global $rodb, $purchaseModel;
        if($start_date!='')
            $condition = " buy_date >= '"._getDBDate($start_date)."' ";
        if($end_date!='')
            if($condition=='')
                $condition = " buy_date <= '"._getDBDate($end_date)."' 23:59:59 ";
            else
                $condition .= " and buy_date <= '"._getDBDate($end_date)." 23:59:59' ";
        $q = "select * from ".$rodb->prefix."buy
        where total = 0 and ".$condition.' order by buy_date asc
        ';
        return $all_purchases = $rodb->getTableFromDB($q);
	}
    function getPurchaseAnalysis($start_date = '', $end_date = ''){
        global $rodb, $purchaseModel;
        if($start_date!='')
            $condition = " buy_date >= '"._getDBDate($start_date)."' ";
        if($end_date!='')
            if($condition=='')
                $condition = " buy_date <= '"._getDBDate($end_date)."' 23:59:59 ";
            else
                $condition .= " and buy_date <= '"._getDBDate($end_date)." 23:59:59' ";
        $condition .= " group by product_id order by productname asc, buy_date asc ";
        $q = "select product_id, sum(quantity) as qty, productname from ".$rodb->prefix."buy_products bp inner join ".$rodb->prefix."product p
        on bp.product_id = p.productid
        where ".$condition." and userid = '".getBusinessId()."'
        ";
        $all_purchases = $rodb->getTableFromDB($q);
        $i=0;
        if(count($all_purchases) > 0){
            foreach($all_purchases as $row){
                $q = "select productname from ".$rodb->prefix."product where productId='".$row['product_id']."' order by productname asc";
                $purchases[$i]['prd_name'] = $rodb->getCellfromDB($q);
                $q_brand = "select cat_name from ".$rodb->prefix."category where cat_id=(select cat_id from ".$rodb->prefix."product where productid='".$row['product_id']."')";
                $purchases[$i]['cat_name'] = $rodb->getCellfromDB($q_brand);
                $q_item = "select tc_name from ".$rodb->prefix."top_category where tc_id=(select cat_tc_id from ".$rodb->prefix."category where cat_id = (select cat_id from ".$rodb->prefix."product where productid='".$row['product_id']."'))";
                $purchases[$i]['tc_name'] = $rodb->getCellfromDB($q_item);
                
                $purchases[$i]['productid'] = $row['product_id'];
                $purchases[$i]['total_qty'] = $row['qty'];
                $i++;
            }
        }
        return $purchases;
    }
    function getAlternateListingClass($class){
        if($class != ' class="row_listing1"')
            return ' class="row_listing1"';
        else
            return ' class="row_listing2"';
    }
    function gatepass_in($file){
        global $rodb, $purchaseModel;
        $h = fopen($file['tmp_name'], 'r');
        $content = '';
        $content .= fread($h, filesize($file['tmp_name']));
        fclose($file);
        $arr = json_decode($content);
        foreach($arr as $k){
            $product = createNewProduct($k->complete_product_name, $k->sale_price);
            $purchaseModel->addPurchaseInCart($product, $k->qty, 0);
        }
        redirect(getPageUrl( "new_purchase" ).'&gatepass=in');
        die;
    }
}
$purchaseController = new PurchaseController();