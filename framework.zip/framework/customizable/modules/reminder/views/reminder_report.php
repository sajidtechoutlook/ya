<link href="<? echo getModuleURL("reminder");?>views/style.css" rel="stylesheet" type="text/css">

<script type="text/javascript">
function productReminderReport(pid){
	$('#productid').val( pid );
	document.new_reminder.submit();
}
</script>

<table align="center" class="Tb3">

	<tr>

		<td colspan="5" align="center">

			<strong style="font-size:24px; color:#000066; font-family:'Courier New', Courier, monospace"></strong><br /><br /><br /><font color="#FF0000"><?=$_REQUEST['msg']?></font>

		</td>

	</tr>

	<tr style="display: none;">

		<td width="100%" align="center">

			<form id="new_reminder" name="new_reminder" method="post" action="">

			<input type="hidden" name="reminder_report_action" value="generate" />

			<input type="hidden" id="productid" name="productid" value="" />

				<table class="TB3">

					<tr>

						<td><strong>Start Date:</strong></td><td><input type="start_date" id="start_date" name="start_date" value="<?=$_POST['start_date']?>" /></td>

						<td><strong>End Date:</strong></td><td><input type="end_date" id="end_date" name="end_date" value="<?=$_POST['end_date']?>" /></td>

						<td><input type="submit" class="btn_submit" name="generate" id="generate" value="Generate" /></td>

					</tr>

				</table>

			</form>

		</td>

	</tr>

	<? 

	//if( $_POST['reminder_report_action']=='generate' )
	{ 

	?>

	<tr>

		<td>

			<table class="main_tbl_listing" border="0" cellpadding="5" cellspacing="0">
				<?
				if( !empty($data['reminders']) ){
					
				?>
					<tr class="tbl_listing_heading">
						<td>Date</td>
						<td>Reminder</td>
						<td>Action</td>
					</tr>
				<?
					foreach( $data['reminders'] as $row ){

						$class = $reminderController->getAlternateListingClass($class);

				?>
					<tr <?=$class?>>
						<td><?=_retDate($row['dt']);?></td>
						<td><?=($row['description']);?></td>
						<td><a href="javascript:;" onclick="if(confirm('Do you really want to delete this reminder?')) window.location='<?php echo getPageUrl('delete&amp;type=reminder&amp;id='.$row['id'])?>';">Delete</a></td>
					</tr>

					<?

					}

				}else{

					echo "No Reminder Found.";

				}

				?>

			</table>

		</td>

	</tr>

	<? } ?>

</table>

<!-- <script>

    $( function() {

        var $sd = $( "#start_date" ).val( );

        var $ed = $( "#end_date" ).val( );

        

        $( "#start_date" ).datepicker( );

        $( "#start_date" ).datepicker( "option", "dateFormat", "dd-mm-yy" );

        

        $( "#end_date" ).datepicker( );

        $( "#end_date" ).datepicker( "option", "dateFormat", "dd-mm-yy" );

        

        $( "#start_date" ).val($sd);

        $( "#end_date" ).val($ed);

    } );

</script> -->