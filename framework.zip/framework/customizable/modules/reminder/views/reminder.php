<table align="center" class="Tb3">

	<tr>

		<td colspan="5" align="center">

			<strong style="font-size:24px; color:#000066; font-family:'Courier New', Courier, monospace">New Reminder</strong><br /><br /><br /><font color="#FF0000"><?php echo $_REQUEST['msg']?></font>

		</td>

	</tr>

	<tr>

      <td colspan="5" width="100%" align="center">

		<form id="new_reminder" name="new_reminder" method="post" action="">

		<input type="hidden" name="reminder_form_action" value="save" />

			<table class="Tb3">

				<tr>

					<td align="left">Date</td>

					<td align="left">

						<input type="text" name="dt" id="dt" value="<?php echo date('d-m-Y')?>" />

					</td>

				</tr>

				<tr>

					<td align="left">Reminder</td>

					<td align="left">

						<textarea name="description" id="description" cols="45" rows="9"></textarea>

					</td>

				</tr>

				<tr>

					<td align="left"></td>

					<td align="left">

						<input type="submit" name="save" value="Save" />

					</td>

				</tr>

			</table>

		</form>

	  </td>

	</tr>

</table>
<script>

    $( function() {
        var $sd = $( "#dt" ).val( );
        $( "#dt" ).datepicker( );
        $( "#dt" ).datepicker( "option", "dateFormat", "dd-mm-yy" );
        $( "#dt" ).val($sd);
		
		$('#amount').focus();
    } );

</script>