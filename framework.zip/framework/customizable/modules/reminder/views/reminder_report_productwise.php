<?php 
$q = "select * from ".$rodb->prefix."buy_products where product_id='".$rodb->mysql_real_escape_string($_GET['productid'])."'";
$reminders = $rodb->getTableFromDB($q);
?>
<link href="<? echo getModuleURL("reminder");?>views/style.css" rel="stylesheet" type="text/css">
<table align="center" class="Tb3">
	<tr>
		<td colspan="5" align="center">
			<strong style="font-size:24px; color:#000066; font-family:'Courier New', Courier, monospace"><?php echo $rodb->getCellFromDB("select productname from ".$rodb->prefix."product where productid='".mysql_real_escape_string($_POST['productid'])."'");?> Reminder report</strong><br /><br /><br /><font color="#FF0000"><?=$_REQUEST['msg']?></font>
		</td>
	</tr>
	<? 
	//if( $_POST['reminder_report_action']=='generate' )
	{ 
	?>

	<tr>

		<td>

			<table class="main_tbl_listing" border="0" cellpadding="5" cellspacing="0">

				<?php

				
				if( count($reminders) > 0 ){

				?>

					<tr class="tbl_listing_heading">

						<td>Date</td>

						<td>Quantity</td>

					</tr>

				<?php
				$i=0;
					while($row = $reminders[$i]){

						$class = $reminderController->getAlternateListingClass($class);

				?>

					<tr <?=$class?>>

						<td><a href="<? echo getPageUrl('find_reminder').'&rtno='.$row['buy_id'];?>"><?php echo _retDate($row['buy_date']);?></a></td>

						<td><?=$row['quantity']?></td>

					</tr>

					<?
						$i++;
					}

				}else{

					echo "No Reminder Found.";

				}

				?>

			</table>

		</td>

	</tr>

	<?php } ?>

</table>