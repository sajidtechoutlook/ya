<?php
class ReminderController{
    function getReminders($start_date = '', $end_date = ''){
		global $rodb, $reminderModel;
        if($start_date!='')
            $condition = " dt >= '"._getDBDate($start_date)."' ";
        if($end_date!='')
            if($condition=='')
                $condition = " dt <= '"._getDBDate($end_date)."' 23:59:59 ";
            else
                $condition .= " and dt <= '"._getDBDate($end_date)." 23:59:59' ";
        $condition = " userid='".getBusinessId()."'";
		
		$q = "select * from ".$rodb->prefix."reminders
        where ".$condition.' order by dt asc
        ';
        return $all_reminders = $rodb->getTableFromDB($q);
	}
    function getGatePasses($start_date = '', $end_date = ''){
		global $rodb, $reminderModel;
        if($start_date!='')
            $condition = " buy_date >= '"._getDBDate($start_date)."' ";
        if($end_date!='')
            if($condition=='')
                $condition = " buy_date <= '"._getDBDate($end_date)."' 23:59:59 ";
            else
                $condition .= " and buy_date <= '"._getDBDate($end_date)." 23:59:59' ";
        $q = "select * from ".$rodb->prefix."buy
        where total = 0 and ".$condition.' order by buy_date asc
        ';
        return $all_reminders = $rodb->getTableFromDB($q);
	}
    function getReminderAnalysis($start_date = '', $end_date = ''){
        global $rodb, $reminderModel;
        if($start_date!='')
            $condition = " buy_date >= '"._getDBDate($start_date)."' ";
        if($end_date!='')
            if($condition=='')
                $condition = " buy_date <= '"._getDBDate($end_date)."' 23:59:59 ";
            else
                $condition .= " and buy_date <= '"._getDBDate($end_date)." 23:59:59' ";
        $condition .= " group by product_id order by productname asc, buy_date asc ";
        $q = "select product_id, sum(quantity) as qty, productname from ".$rodb->prefix."buy_products bp inner join ".$rodb->prefix."product p
        on bp.product_id = p.productid
        where ".$condition.' 
        ';
        $all_reminders = $rodb->getTableFromDB($q);
        $i=0;
        if(count($all_reminders) > 0){
            foreach($all_reminders as $row){
                $q = "select productname from ".$rodb->prefix."product where productId='".$row['product_id']."' order by productname asc";
                $reminders[$i]['prd_name'] = $rodb->getCellfromDB($q);
                $q_brand = "select cat_name from ".$rodb->prefix."category where cat_id=(select cat_id from ".$rodb->prefix."product where productid='".$row['product_id']."')";
                $reminders[$i]['cat_name'] = $rodb->getCellfromDB($q_brand);
                $q_item = "select tc_name from ".$rodb->prefix."top_category where tc_id=(select cat_tc_id from ".$rodb->prefix."category where cat_id = (select cat_id from ".$rodb->prefix."product where productid='".$row['product_id']."'))";
                $reminders[$i]['tc_name'] = $rodb->getCellfromDB($q_item);
                
                $reminders[$i]['productid'] = $row['product_id'];
                $reminders[$i]['total_qty'] = $row['qty'];
                $i++;
            }
        }
        return $reminders;
    }
    function getAlternateListingClass($class){
        if($class != ' class="row_listing1"')
            return ' class="row_listing1"';
        else
            return ' class="row_listing2"';
    }
    function gatepass_in($file){
        global $rodb, $reminderModel;
        $h = fopen($file['tmp_name'], 'r');
        $content = '';
        $content .= fread($h, filesize($file['tmp_name']));
        fclose($file);
        $arr = json_decode($content);
        foreach($arr as $k){
            $product = createNewProduct($k->complete_product_name, $k->sale_price);
            $reminderModel->addReminderInCart($product, $k->qty, 0);
        }
        redirect(getPageUrl( "new_reminder" ).'&gatepass=in');
        die;
    }
}
$reminderController = new ReminderController();