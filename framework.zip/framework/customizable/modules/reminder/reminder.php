<?php
include('models/reminder.php');
include('reminder_controller_class.php');

function reminder(){
	global $reminderModel, $reminderController, $rodb;
    if($_GET['type']=='report'){
        $_POST['reminder_report_action'] = 'generate';
        if(empty($_POST['start_date'])) $_POST['start_date'] = date('1-m-Y');
        if(empty($_POST['end_date'])) $_POST['end_date'] = date('d-m-Y');
        if( $_POST['reminder_report_action']=='generate' ){
			if($_GET['analysis']=='yes'){
				$data['reminder_analysis'] = $reminderController->getReminderAnalysis($_POST['start_date'], $_POST['end_date']);
			}elseif($_GET['gatepass']=='yes'){
				$data['reminders'] = $reminderController->getGatepasses($_POST['start_date'], $_POST['end_date']);
			}else{
				$data['reminders'] = $reminderController->getReminders($_POST['start_date'], $_POST['end_date']);
			}
        }
        if(!empty($_GET['productid'])){
            include('views/reminder_report_productwise.php');
        }elseif($_GET['analysis']=='yes'){
            include('views/reminder_analysis.php');
        }elseif($_GET['gatepass'] == 'yes'){
            include('views/gatepass_report.php');
        }else{
            include('views/reminder_report.php');
        }
    }else{
        if(!empty($_POST['product_search']))
            $_REQUEST['product'] = $_POST['product'] = createNewProduct($_POST['product_search'], $_POST['sale_price'], $_POST['price']);
        if( $_POST['reminder_form_action'] == 'add' ){
            $_POST['product'] = createNewProduct($_POST['product_search'], $_POST['sale_price'], $_POST['price']);
            $reminderModel->addReminderInCart($_POST['product'],$_POST['qty'],$_POST['qty_packs'],$_POST['price']);
        }elseif( $_POST['reminder_form_action'] == 'save' ){
			if($_SESSION['ses_edit_reminder'] > 0){
				$reminder_id = $_SESSION['ses_edit_reminder'];
				$reminderModel->updateReminder($reminder_id);
				unset($_SESSION['ses_edit_reminder']);
			}else{
				$reminder_id = $reminderModel->saveReminder();
				if($_GET['gatepass']=='in'){
					redirect(getPageUrl( "new_reminder" ));
					die;
				}
			}
            redirect(getPageUrl( "new_reminder" ));
            die;
        }elseif(isset($_FILES['gatepass_file'])){
            $reminderController->gatepass_in($_FILES['gatepass_file']);
            redirect();
        }
        if( $_GET['action'] == 'delete' ){
            $reminderModel->deleteReminderFromCart($_GET['product_id']);
        }
        $reminderModel->updateReminderCart();
        if($_GET['gatepass']=='in')
            include('views/gatepass.php');
        else
            include('views/reminder.php');
    }
}