<?php 
$q = "select * from ".$rodb->prefix."buy_products where product_id='".mysql_real_escape_string($_POST['productid'])."'";

$purchases = mysql_query($q);

?>

<link href="<? echo getModuleURL("purchase");?>views/style.css" rel="stylesheet" type="text/css">

<table align="center" class="Tb3">

	<tr>

		<td colspan="5" align="center">

			<strong style="font-size:24px; color:#000066; font-family:'Courier New', Courier, monospace"><?php echo $rodb->getCellFromDB("select productname from ".$rodb->prefix."product where productid='".mysql_real_escape_string($_POST['productid'])."'");?> Purchase report</strong><br /><br /><br /><font color="#FF0000"><?=$_REQUEST['msg']?></font>

		</td>

	</tr>

	<tr>

		<td width="100%" align="center">

			<form id="new_purchase" name="new_purchase" method="post" action="">

			<input type="hidden" name="purchase_report_action" value="generate" />

			<input type="hidden" name="productid" value="<?php echo mysql_real_escape_string($_POST['productid'])?>" />

				<table class="TB3">

					<tr>

						<td><strong>Start Date:</strong></td><td><input type="start_date" id="start_date" name="start_date" value="<?=mysql_real_escape_string($_POST['start_date'])?>" /></td>

						<td><strong>End Date:</strong></td><td><input type="end_date" id="end_date" name="end_date" value="<?=mysql_real_escape_string($_POST['end_date'])?>" /></td>

						<td><input type="submit" class="btn_submit" name="generate" id="generate" value="Generate" /></td>

					</tr>

				</table>

			</form>

		</td>

	</tr>

	<? 

	if( $_POST['purchase_report_action']=='generate' ){ 

	?>

	<tr>

		<td>

			<table class="main_tbl_listing" border="0" cellpadding="5" cellspacing="0">

				<?php

				

				if( mysql_num_rows($purchases) > 0 ){

				?>

					<tr class="tbl_listing_heading">

						<td>Date</td>

						<td>Quantity</td>

					</tr>

				<?php

					while($row = mysql_fetch_array($purchases)){

						$class = $purchaseController->getAlternateListingClass($class);

				?>

					<tr <?=$class?>>

						<td><?=_retDate($row['buy_date'])?></a></td>

						<td><?=$row['quantity']?></td>

					</tr>

					<?

					}

				}else{

					echo "No Purchase Found.";

				}

				?>

			</table>

		</td>

	</tr>

	<?php } ?>

</table>