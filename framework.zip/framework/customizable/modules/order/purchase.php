<?php
include('models/purchase.php');
include('purchase_controller_class.php');
/*
addMenuItem(array("url" => "new_purchase.php", "text" => "Purchase", "sub_menu" => array(
	0 => array("id" => "purchase", "url" => $webUrl."?page=new_purchase", "text"=>" Purchase"),
	1 => array("id" => "purchase_report", "url" => $webUrl."?page=new_purchase&type=report", "text"=>" Purchase report")
)));
*/
function purchase(){
	global $purchaseModel, $purchaseController, $rodb;
	
	if($_GET['type']=='report'){
            $_POST['purchase_report_action'] = 'generate';
            if(empty($_POST['start_date'])) $_POST['start_date'] = date('1-m-Y');
            if(empty($_POST['end_date'])) $_POST['end_date'] = date('d-m-Y');
            if( $_POST['purchase_report_action']=='generate' ){
                    $data['purchases'] = $purchaseController->getPurchases($_POST['start_date'], $_POST['end_date']);
            }
            if(!empty($_POST['productid'])){
                    include('views/purchase_report_productwise.php');
            }else{
                    include('views/purchase_report.php');
            }
	}else{
            if(!empty($_POST['product_search']))
                $_REQUEST['product'] = $_POST['product'] = createNewProduct($_POST['product_search'], $_POST['price']);
            
            if( $_POST['purchase_form_action'] == 'add' ){
                $_POST['product'] = createNewProduct($_POST['product_search'], $_POST['price']);
                    $purchaseModel->addPurchaseInCart($_POST['product'],$_POST['qty'],$_POST['price']);
            }elseif( $_POST['purchase_form_action'] == 'save' ){
                    $purchase_id = $purchaseModel->savePurchase();
                    redirect(getPageUrl( "find_purchase" ).'&rtno='.$purchase_id);
                    exit;
            }
            if( $_GET['action'] == 'delete' ){
                    $purchaseModel->deletePurchaseFromCart($_GET['product_id']);
            }

            $purchaseModel->updatePurchaseCart();
            include('views/purchase.php');
	}
}
//purchase();
?>