<?
/*
-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Jun 24, 2010 at 06:41 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `stockmanagementv7`
-- 
*/

include ('ro-config.php');
createTables($rodb, $rodb->prefix);
?>