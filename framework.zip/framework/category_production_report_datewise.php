<? 
//include ('header.php');
include('ro-config.php');

foreach($_REQUEST as $key => $val){
	$$key = stripslashes($val);
}
$error = "";

if($generate=='generate'){
	if($start_date==''){
		$error .= " - Start Date is Required";
	}
	if($end_date==''){
		$error .= " - End Date is Required";
	}
}
?>
	<script type="text/javascript">
	//<![CDATA[
		$(document).ready(function (){
			$("#start_date").calendar();
			$("#end_date").calendar();
//			$("#calendar1_alert").click(function(){alert(popUpCal.parseDate($('#calendar1').val()))});
		});
	//]]>
	</script>
	<table width="100%" align="center" cellpadding="0" cellspacing="0" border="0">
		<tr><td align="center"><h1>Production Report</h1></td></tr>
		<tr><td height="10"></td></tr>
<?
if($error=="" && $generate=='generate'){
	$start_date_formatted = explode(" ",$start_date);
	$start_date_formatted = explode("-",$start_date_formatted[0]);
	$start_date_formatted = $start_date_formatted[2]."-".$start_date_formatted[1]."-".$start_date_formatted[0];
	
	$end_date_formatted = explode(" ",$end_date);
	$end_date_formatted = explode("-",$end_date_formatted[0]);
	$end_date_formatted = $end_date_formatted[2]."-".$end_date_formatted[1]."-".$end_date_formatted[0];
	
	$start_date_formatted = _getDBDate($start_date);
	$end_date_formatted = _getDBDate($end_date);
	
	$resultsq = "select * from ".$rodb->prefix."product where userid='".getBusinessId()."' and cat_id='".$_REQUEST['catid']."'";
	$results = $dblink->getTableFromDB($resultsq);
	if($results[0]){
?>
<form action="<?=getPageUrl("product_production_report_datewise")?>" method="post" name="prdw" id="prdw" target="_blank">
	<input type="hidden" name="start_date" id="start_date" value="<?=$start_date?>" />
	<input type="hidden" name="end_date" id="end_date" value="<?=$end_date?>" />
	<input type="hidden" name="productid" id="productid" value="productid" />
</form>
		<tr>
			<td width="100%" align="center">
				<table width="100%" align="center">
					<tr>
						<td align="center">
							<strong>From: <?=_getOnlyDate($start_date);?></strong>
						</td>
						<td align="center">
							<strong>To: <?=_getOnlyDate($end_date);?></strong>
						</td>
					</tr>
				</table>
			</td>
		</tr>
		<tr>
			<td>
				<table width="100%" align="center" cellpadding="3" cellspacing="0" border="1">
					<tr>
						<th align="left">Item</th>
						<th align="left">Brand</th>
						<th align="left">Name / Size</th>
						<th align="left">Quantity</th>
					</tr>
					<?
					$i=0;
					while($results[$i]){
						
						$cat = $dblink->getTableFromDB("select * from ".$rodb->prefix."category where cat_id='".$results[$i]['cat_id']."' and user_id='".getBusinessId()."'");
						$tcat = $dblink->getTableFromDB("select * from ".$rodb->prefix."top_category where tc_id='".$cat[0]['cat_tc_id']."' and tc_user_id='".getBusinessId()."'");
						/*
						echo $prev_qty_q = "select sum(qty) from production_products where userid='".getBusinessId()."' and productid='".$results[$i]['productid']."' and dt < '".$start_date_formatted."' ";
						$prev_qty = $dblink->getCellFromDB($prev_qty_q);
						*/
						$qty = $dblink->getCellFromDB("select sum(qty) from ".$rodb->prefix."production_products where userid='".getBusinessId()."' and productid='".$results[$i]['productid']."' and dt between '".$start_date_formatted."' and '".$end_date_formatted."'");
						$later_qty = $prev_qty + $qty;
						
						
					?>
						<tr>
							<td><?=$tcat[0]['tc_name']?></td>
							<td><?=$cat[0]['cat_name']?></td>
							<td><a href="#" onclick="
								document.prdw.productid.value='<?=$results[$i]['productid']?>';
								document.prdw.submit();
							" style="color:#000000"><?=$results[$i]['productname']?></a></td>
							<td><? 
								if($qty > 0){echo $qty;}else{echo "0";}
								$total_qty += $qty;
							?></td>
						</tr>
					<?
						$i++;
					}
					?>
					<tr>
						<td colspan="3" align="right"><strong>Total</strong></td>
						<td><strong><?=$total_qty?></strong></td>
					</tr>
				</table>
			</td>
		</tr>
<?
	}else{
		echo("<tr><td>Sorry, no results found</td></tr>");
	}
}
?>
	</table>
<? //include ('footer.php'); ?>