<?php
$q_customers = "select * from ".$rodb->prefix."customers where user_id = '".getBusinessId()."'";
$res = $rodb->getTableFromDB($q_customers);

if(isset($res) && count($res) > 0)
foreach($res as $rec){
    $item_res = explode('-', $rec['customer_name']);
    if(isset($item_res['2'])){
        echo '<br />'.
        $q = 
        "update ".$rodb->prefix."customers set customer_name = '".$item_res['2']."' where
        customer_id = '".$rec['customer_id']."'
        ";
        $rodb->execute($q);
    }
}
