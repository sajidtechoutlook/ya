<? 
	include"ro-config.php"; 
	//include"classes/db.php"; 
	include "check.php";
?>
  <table border="0" align="center" width="50%">
	<tr>
		<td align="center" style="color:#FF0000" colspan="8"><strong style="font-size:18px">Stock List</strong></td>
	</tr>
	<?
	$prdnameq = " 
	select 
		* 
	from 
		product prd inner join ".$rodb->prefix."category cat
		on prd.cat_id = cat.cat_id
		and cat.cat_id = '".$_REQUEST['catid']."' 
		and userid = '".getBusinessId()."'
	";
	$prdnames = $dblink->getTableFromDB($prdnameq);
	?>
    <tr>
      <th width="42%" align="left">Brand</th>
      <th width="29%" align="left">Size</th>
      <th width="29%" align="left">Stock</th>
    </tr>
	<?
	$i=0;
	while($prdnames[$i])
	{
	?>
    <tr>
      <td><?=$prdnames[$i]['cat_name']?></td>
      <td><?=$prdnames[$i]['productname']?></td>
      <td><?=$prdnames[$i]['stock']?></td>
    </tr>
    <?
		$i++;
	}
	?>
  </table>